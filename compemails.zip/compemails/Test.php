<?php

    /*$msg = wordwrap("Lorem ipsum dolor sit, amet consectetur adipisicing elit. Earum repellat adipisci laborum? Culpa sequi magni doloribus earum delectus illo inventore ad natus aperiam voluptatibus. Iste odit voluptatem commodi saepe quaerat.", 70, "\r\n");
    $headers = [
        "From" => "master@dioceseparis.fr",
        "Reply-To" => "master@dioceseparis.fr"
    ];


    mail('test-42zctpwnz@srv1.mail-tester.com', 'Test', $msg, $headers);*/


    /*require 'vendor/autoload.php';
    use \Mailjet\Resources;
    $mj = new \Mailjet\Client('232aaf73f54e28d484fa2dfcf7fcfe5a','fdf18b8389dfe15fd7ef85ce45f0f06b',true,['version' => 'v3.1']);
    $body = [
    'Messages' => [
    [
    'From' => [
    'Email' => "nlonghi@diocese-paris.net",
    'Name' => "Nicolas"
    ],
    'To' => [
    [
    'Email' => "nlonghi@diocese-paris.net",
    'Name' => "Nicolas"
    ]
    ],
    'Subject' => "Greetings from Mailjet.",
    'TextPart' => "My first Mailjet email",
    'HTMLPart' => "<h3>Dear passenger 1, welcome to <a href='https://www.mailjet.com/'>Mailjet</a>!</h3><br />May the delivery force be with you!",
    'CustomID' => "AppGettingStartedTest"
    ]
    ]
    ];
    $response = $mj->post(Resources::$Email, ['body' => $body]);
    $response->success() && var_dump($response->getData());*/


    /*$body = [
        'Messages' => [
            [
            'From' => [
                'Email' => "nlonghi@diocese-paris.net",
                'Name' => "Diocese"
            ],
            'To' => [
                [
                    'Email' => "test-42zctpwnz@srv1.mail-tester.com",
                    'Name' => "Test"
                ]
            ],
            'Subject' => "Sujet de test.",
            'HTMLPart' => "<h3>Ceci est un merveilleux test !</h3><br/> J'utilise HTML pour écrire ce mail"
            ]
        ]
    ];
      
    $ch = curl_init();
      
    curl_setopt($ch, CURLOPT_URL, "https://api.mailjet.com/v3.1/send");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
        'Content-Type: application/json')
    );
    curl_setopt($ch, CURLOPT_USERPWD, "232aaf73f54e28d484fa2dfcf7fcfe5a:fdf18b8389dfe15fd7ef85ce45f0f06b");
    $server_output = curl_exec($ch);
    curl_close ($ch);
      
    $response = json_decode($server_output);
    if ($response->Messages[0]->Status == 'success') {
        echo "Email sent successfully.";
    }*/



   /* require 'vendor/autoload.php';
    use \Mailjet\Resources;
    $mj = new \Mailjet\Client('41504edc5f1f84a9c40b8b7cd61e3cbd', '97777a1f90d88c2787f016e4eb3b1bae',true,['version' => 'v3.1']);
    $response = $mj->get(Resources::$Messagehistory, ['id' => 'li65D0vEvi']);
    $response->success() && var_dump($response->getData());
    var_dump($response);*/
    
    /*putenv("MJ_APIKEY_PUBLIC=41504edc5f1f84a9c40b8b7cd61e3cbd");
    putenv("MJ_APIKEY_PRIVATE=97777a1f90d88c2787f016e4eb3b1bae");

    require 'vendor/autoload.php';
    use \Mailjet\Resources;
    $mj = new \Mailjet\Client(getenv('MJ_APIKEY_PUBLIC'), getenv('MJ_APIKEY_PRIVATE'), true, ['version' => 'v3.1']);
    $body = [
        'Messages' => [
            [
                'From' => [
                    'Email' => "master@diocese-paris.net",
                    'Name' => "Me"
                ],
                'To' => [
                    [
                        'Email' => "nlonghi@diocese-paris.net",
                        'Name' => "You"
                    ]
                ],
                'Subject' => "My first Mailjet Email!",
                'TextPart' => "Greetings from Mailjet!",
                'HTMLPart' => "<h3>Dear passenger 1, welcome to <a>Mailjet</a>!</h3><br />May the delivery force be with you!"
            ]
        ]
    ];
    $response = $mj->post(Resources::$Email, ['body' => $body]);
    $response->success() && var_dump($response->getData());
    var_dump($response);*/
   
  /*require 'vendor/autoload.php';
  use \Mailjet\Resources;
  $mj = new \Mailjet\Client('41504edc5f1f84a9c40b8b7cd61e3cbd', '97777a1f90d88c2787f016e4eb3b1bae', true, ['version' => 'v3.1']);
  $body = [
    'Messages' => [
      [
        'From' => [
          'Email' => "nlonghi@diocese-paris.net",
          'Name' => "Nicolas"
        ],
        'To' => [
          [
            'Email' => "nlonghi@diocese-paris.net",
            'Name' => "Nicolas"
          ]
        ],
        'Subject' => "Greetings from Mailjet.",
        'TextPart' => "My first Mailjet email",
        'HTMLPart' => "<h3>Dear passenger 1, welcome to <a href='https://www.mailjet.com/'>Mailjet</a>!</h3><br />May the delivery force be with you!",
        'CustomID' => "AppGettingStartedTest"
      ]
    ]
  ];
  $response = $mj->post(Resources::$Email, ['body' => $body]);
  $response->success() && var_dump($response->getData());*/
  //var_dump($response->success);

  
  /*require 'vendor/autoload.php';
  use \Mailjet\Resources;
  $mj = new \Mailjet\Client('41504edc5f1f84a9c40b8b7cd61e3cbd', '97777a1f90d88c2787f016e4eb3b1bae',true,['version' => 'v3']);
  $response = $mj->get(Resources::$Message);
  $response->success() && var_dump($response->getData());*/
  
 
  /*
  //View : Retrieve Key Delivery statistics for a Specific Campaign
  //Stats par compagne
  require 'vendor/autoload.php';
  use \Mailjet\Resources;
  $mj = new \Mailjet\Client('41504edc5f1f84a9c40b8b7cd61e3cbd', '97777a1f90d88c2787f016e4eb3b1bae');
  $filters = [
    'SourceId' => '43468',
    'CounterSource' => 'Campaign',
    'CounterTiming' => 'Message',
    'CounterResolution' => 'Lifetime'
  ];
  $response = $mj->get(Resources::$Statcounters, ['filters' => $filters]);
  $response->success() && var_dump($response->getData());*/

  







    //Recup tous les contacts
    /*require 'vendor/autoload.php';
    use \Mailjet\Resources;
    $mj = new \Mailjet\Client('41504edc5f1f84a9c40b8b7cd61e3cbd', '97777a1f90d88c2787f016e4eb3b1bae',true,['version' => 'v3']);
    $response = $mj->get(Resources::$Contact);
    $response->success() && var_dump($response->getData());*/







    //Recup le détail de toutes les compagnes
    /*require 'vendor/autoload.php';
    use \Mailjet\Resources;
    $mj = new \Mailjet\Client('41504edc5f1f84a9c40b8b7cd61e3cbd', '97777a1f90d88c2787f016e4eb3b1bae',true,['version' => 'v3']);
    $response = $mj->get(Resources::$Campaign);
    $response->success() && var_dump($response->getData());*/


    //Recup détail une seule campagne
    /*require 'vendor/autoload.php';
    use \Mailjet\Resources;
    $mj = new \Mailjet\Client('41504edc5f1f84a9c40b8b7cd61e3cbd', '97777a1f90d88c2787f016e4eb3b1bae',true,['version' => 'v3']);
    $response = $mj->get(Resources::$Campaignstatistics, ['id' => '43468']);
    $response->success() && var_dump($response->getData());*/


    //Recup détail tous les mails
    /*require 'vendor/autoload.php';
    use \Mailjet\Resources;
    $mj = new \Mailjet\Client('41504edc5f1f84a9c40b8b7cd61e3cbd', '97777a1f90d88c2787f016e4eb3b1bae',true,['version' => 'v3']);
    $response = $mj->get(Resources::$Messagestatistics);
    $response->success() && var_dump($response->getData());*/







    //Recup info message
    /*require 'vendor/autoload.php';
    use \Mailjet\Resources;
    $mj = new \Mailjet\Client('41504edc5f1f84a9c40b8b7cd61e3cbd', '97777a1f90d88c2787f016e4eb3b1bae',true,['version' => 'v3']);
    $response = $mj->get(Resources::$Message);
    $response->success() && var_dump($response->getData());*/









    //Recup stats message par ID
    /*require 'vendor/autoload.php';
    use \Mailjet\Resources;
    $mj = new \Mailjet\Client('41504edc5f1f84a9c40b8b7cd61e3cbd', '97777a1f90d88c2787f016e4eb3b1bae',true,['version' => 'v3']);
    $response = $mj->get(Resources::$Messagesentstatistics, ['id' => '1152921517307999079']);
    $response->success() && var_dump($response->getData());*/

    /*require 'vendor/autoload.php';
    use \Mailjet\Resources;
    $mj = new \Mailjet\Client('41504edc5f1f84a9c40b8b7cd61e3cbd', '97777a1f90d88c2787f016e4eb3b1bae',true,['version' => 'v3']);
    $response = $mj->get(Resources::$Messagesentstatistics);
    $response->success() && var_dump($response->getData());*/



  /*

    
    require 'vendor/autoload.php';
    use \Mailjet\Resources;
    $mj = new \Mailjet\Client('41504edc5f1f84a9c40b8b7cd61e3cbd', '97777a1f90d88c2787f016e4eb3b1bae', true, ['version' => 'v3']);

    $listeContact = $mj->get(Resources::$Contact);
    //$listeContact->success() && var_dump($listeContact->getData());

    $listeMails = $mj->get(Resources::$Message);
    //$listeMails->success() && var_dump($listeMails->getData());

    $tempArrived = array();
    $tempInfo = array();
    $liste = array();
    foreach ($listeContact->getData() as $contact) {
        $i = 1;
        foreach ($listeMails->getData() as $mail) {
            if ($contact['ID'] == $mail['ContactID']) {
                $tempArrived[$i] = $mail['ArrivedAt'];
                $tempInfo[$i] = array($mail['Status'], $contact['Email']);
            }
            $i++;
        }
        $key = array_search(max($tempArrived), $tempArrived);
        array_push($liste, $tempInfo[$key]);
    }
    //var_dump($tempArrived);

    $liste = json_encode($liste, true);
    var_dump($liste);
    */

    /*$response = $mj->get(Resources::$Messagestatistics, ['id' => '1152921517306986609']);
    $response->success() && var_dump($response->getData());*/

?>




<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Document</title>
</head>

<body>


<?php



  /*$url = "http://sc-10cnd-jasper/jasperserver/rest_v2/reports/exports/mailist.csv";

  $curl = curl_init($url);
  curl_setopt($curl, CURLOPT_URL, $url);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

  $headers = array(
    "Authorization: Basic amFzcGVyX2NvbTpmV1hzeE1LaGJmdUIwSnQ4RkJaUw==",
  );
  curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
  //for debug only!
  curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
  curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

  $resp = curl_exec($curl);
  curl_close($curl);
  var_dump($resp);*/

  /*$api_url = 'http://sc-10cnd-jasper/jasperserver/rest_v2/reports/exports/mailist.csv';

  $client_id = 'myclientid';
  $client_secret = 'myclientsecret';

  $context = stream_context_create(array(
      'http' => array(
          'header' => "Authorization: Basic" . base64_encode("$client_id:$client_secret"),
      ),
  ));

  $result = file_get_contents($api_url, false, $context);*/
  
  //header('Authorization: Basic amFzcGVyX2NvbTpmV1hzeE1LaGJmdUIwSnQ4RkJaUw==');
  //header("Location: http://sc-10cnd-jasper/jasperserver/rest_v2/reports/exports/mailist.csv");

  
  /*$curlHandler = curl_init();

  $userName = 'exalide';
  $password = 'export';

  curl_setopt_array($curlHandler, [
      CURLOPT_URL => 'http://sc-10cnd-jasper/jasperserver/rest_v2/reports/exports/mailist.csv',
      CURLOPT_RETURNTRANSFER => true,

      CURLOPT_HTTPAUTH => CURLAUTH_BASIC,
      CURLOPT_USERPWD => $userName . ':' . $password,
  ]);

  $response = curl_exec($curlHandler);
  curl_close($curlHandler);
  var_dump($response);*/

?>








<!--<nav id="navbar-example2" class="navbar fixed-top navbar-light bg-light px-3">
  <a class="navbar-brand" href="#">Navbar</a>
  <ul class="nav nav-pills">
    <li class="nav-item">
      <a class="nav-link" href="#scrollspyHeading1">First</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#scrollspyHeading2">Second</a>
    </li>
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false">Dropdown</a>
      <ul class="dropdown-menu">
        <li><a class="dropdown-item" href="#scrollspyHeading3">Third</a></li>
        <li><a class="dropdown-item" href="#scrollspyHeading4">Fourth</a></li>
        <li><hr class="dropdown-divider"></li>
        <li><a class="dropdown-item" href="#scrollspyHeading5">Fifth</a></li>
      </ul>
    </li>
  </ul>
</nav>

  
<div data-bs-spy="scroll" data-bs-target="#navbar-example2" data-bs-offset="0" class="scrollspy-example" tabindex="0">
  <h4 id="scrollspyHeading1">First heading</h4>
  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. V
    oluptatibus necessitatibus fugit exercitationem ipsam illum, inventore quaerat iste voluptas, blanditiis consequatur atque cumque consequuntur dolorem fuga fugiat ducimus mollitia quia pr
    ovident. Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eos numquam officia earum quidem adipisci. Distinctio recusandae quibusdam mollitia molestias aliquid, obcaecati architecto
     delectus illo ut corrupti quis similique fugit tempore! Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis esse porro voluptas cum, accusantium sint libero in officiis vel nesciunt
      sit cumque ea repudiandae mollitia. Voluptate optio distinctio ratione recusandae! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sit, sed. E
    rror quis impedit doloremque voluptatem fuga veritatis, officiis quaerat accusamus nisi rem ipsam porro repellendus accusantium id temporibus ad alias?Lorem ipsum dolor sit amet consectetur adipisicing elit. V
    oluptatibus necessitatibus fugit exercitationem ipsam illum, inventore quaerat iste voluptas, blanditiis consequatur atque cumque consequuntur dolorem fuga fugiat ducimus mollitia quia pr
    ovident. Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eos numquam officia earum quidem adipisci. Distinctio recusandae quibusdam mollitia molestias aliquid, obcaecati architecto
     delectus illo ut corrupti quis similique fugit tempore! Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis esse porro voluptas cum, accusantium sint libero in officiis vel nesciunt
      sit cumque ea repudiandae mollitia. Voluptate optio distinctio ratione recusandae! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sit, sed. E
    rror quis impedit doloremque voluptatem fuga veritatis, officiis quaerat accusamus nisi rem ipsam porro repellendus accusantium id temporibus ad alias?Lorem ipsum dolor sit amet consectetur adipisicing elit. V
    oluptatibus necessitatibus fugit exercitationem ipsam illum, inventore quaerat iste voluptas, blanditiis consequatur atque cumque consequuntur dolorem fuga fugiat ducimus mollitia quia pr
    ovident. Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eos numquam officia earum quidem adipisci. Distinctio recusandae quibusdam mollitia molestias aliquid, obcaecati architecto
     delectus illo ut corrupti quis similique fugit tempore! Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis esse porro voluptas cum, accusantium sint libero in officiis vel nesciunt
      sit cumque ea repudiandae mollitia. Voluptate optio distinctio ratione recusandae! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sit, sed. E
    rror quis impedit doloremque voluptatem fuga veritatis, officiis quaerat accusamus nisi rem ipsam porro repellendus accusantium id temporibus ad alias?</p>
  <h4 id="scrollspyHeading2">Second heading</h4>
  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. V
    oluptatibus necessitatibus fugit exercitationem ipsam illum, inventore quaerat iste voluptas, blanditiis consequatur atque cumque consequuntur dolorem fuga fugiat ducimus mollitia quia pr
    ovident. Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eos numquam officia earum quidem adipisci. Distinctio recusandae quibusdam mollitia molestias aliquid, obcaecati architecto
     delectus illo ut corrupti quis similique fugit tempore! Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis esse porro voluptas cum, accusantium sint libero in officiis vel nesciunt
      sit cumque ea repudiandae mollitia. Voluptate optio distinctio ratione recusandae! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sit, sed. E
    rror quis impedit doloremque voluptatem fuga veritatis, officiis quaerat accusamus nisi rem ipsam porro repellendus accusantium id temporibus ad alias?Lorem ipsum dolor sit amet consectetur adipisicing elit. V
    oluptatibus necessitatibus fugit exercitationem ipsam illum, inventore quaerat iste voluptas, blanditiis consequatur atque cumque consequuntur dolorem fuga fugiat ducimus mollitia quia pr
    ovident. Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eos numquam officia earum quidem adipisci. Distinctio recusandae quibusdam mollitia molestias aliquid, obcaecati architecto
     delectus illo ut corrupti quis similique fugit tempore! Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis esse porro voluptas cum, accusantium sint libero in officiis vel nesciunt
      sit cumque ea repudiandae mollitia. Voluptate optio distinctio ratione recusandae! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sit, sed. E
    rror quis impedit doloremque voluptatem fuga veritatis, officiis quaerat accusamus nisi rem ipsam porro repellendus accusantium id temporibus ad alias?Lorem ipsum dolor sit amet consectetur adipisicing elit. V
    oluptatibus necessitatibus fugit exercitationem ipsam illum, inventore quaerat iste voluptas, blanditiis consequatur atque cumque consequuntur dolorem fuga fugiat ducimus mollitia quia pr
    ovident. Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eos numquam officia earum quidem adipisci. Distinctio recusandae quibusdam mollitia molestias aliquid, obcaecati architecto
     delectus illo ut corrupti quis similique fugit tempore! Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis esse porro voluptas cum, accusantium sint libero in officiis vel nesciunt
      sit cumque ea repudiandae mollitia. Voluptate optio distinctio ratione recusandae! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sit, sed. E
    rror quis impedit doloremque voluptatem fuga veritatis, officiis quaerat accusamus nisi rem ipsam porro repellendus accusantium id temporibus ad alias?</p>
  <h4 id="scrollspyHeading3">Third heading</h4>
  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. V
    oluptatibus necessitatibus fugit exercitationem ipsam illum, inventore quaerat iste voluptas, blanditiis consequatur atque cumque consequuntur dolorem fuga fugiat ducimus mollitia quia pr
    ovident. Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eos numquam officia earum quidem adipisci. Distinctio recusandae quibusdam mollitia molestias aliquid, obcaecati architecto
     delectus illo ut corrupti quis similique fugit tempore! Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis esse porro voluptas cum, accusantium sint libero in officiis vel nesciunt
      sit cumque ea repudiandae mollitia. Voluptate optio distinctio ratione recusandae! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sit, sed. E
    rror quis impedit doloremque voluptatem fuga veritatis, officiis quaerat accusamus nisi rem ipsam porro repellendus accusantium id temporibus ad alias?Lorem ipsum dolor sit amet consectetur adipisicing elit. V
    oluptatibus necessitatibus fugit exercitationem ipsam illum, inventore quaerat iste voluptas, blanditiis consequatur atque cumque consequuntur dolorem fuga fugiat ducimus mollitia quia pr
    ovident. Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eos numquam officia earum quidem adipisci. Distinctio recusandae quibusdam mollitia molestias aliquid, obcaecati architecto
     delectus illo ut corrupti quis similique fugit tempore! Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis esse porro voluptas cum, accusantium sint libero in officiis vel nesciunt
      sit cumque ea repudiandae mollitia. Voluptate optio distinctio ratione recusandae! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sit, sed. E
    rror quis impedit doloremque voluptatem fuga veritatis, officiis quaerat accusamus nisi rem ipsam porro repellendus accusantium id temporibus ad alias?Lorem ipsum dolor sit amet consectetur adipisicing elit. V
    oluptatibus necessitatibus fugit exercitationem ipsam illum, inventore quaerat iste voluptas, blanditiis consequatur atque cumque consequuntur dolorem fuga fugiat ducimus mollitia quia pr
    ovident. Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eos numquam officia earum quidem adipisci. Distinctio recusandae quibusdam mollitia molestias aliquid, obcaecati architecto
     delectus illo ut corrupti quis similique fugit tempore! Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis esse porro voluptas cum, accusantium sint libero in officiis vel nesciunt
      sit cumque ea repudiandae mollitia. Voluptate optio distinctio ratione recusandae! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sit, sed. E
    rror quis impedit doloremque voluptatem fuga veritatis, officiis quaerat accusamus nisi rem ipsam porro repellendus accusantium id temporibus ad alias?</p>
  <h4 id="scrollspyHeading4">Fourth heading</h4>
  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. V
    oluptatibus necessitatibus fugit exercitationem ipsam illum, inventore quaerat iste voluptas, blanditiis consequatur atque cumque consequuntur dolorem fuga fugiat ducimus mollitia quia pr
    ovident. Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eos numquam officia earum quidem adipisci. Distinctio recusandae quibusdam mollitia molestias aliquid, obcaecati architecto
     delectus illo ut corrupti quis similique fugit tempore! Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis esse porro voluptas cum, accusantium sint libero in officiis vel nesciunt
      sit cumque ea repudiandae mollitia. Voluptate optio distinctio ratione recusandae! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sit, sed. E
    rror quis impedit doloremque voluptatem fuga veritatis, officiis quaerat accusamus nisi rem ipsam porro repellendus accusantium id temporibus ad alias?Lorem ipsum dolor sit amet consectetur adipisicing elit. V
    oluptatibus necessitatibus fugit exercitationem ipsam illum, inventore quaerat iste voluptas, blanditiis consequatur atque cumque consequuntur dolorem fuga fugiat ducimus mollitia quia pr
    ovident. Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eos numquam officia earum quidem adipisci. Distinctio recusandae quibusdam mollitia molestias aliquid, obcaecati architecto
     delectus illo ut corrupti quis similique fugit tempore! Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis esse porro voluptas cum, accusantium sint libero in officiis vel nesciunt
      sit cumque ea repudiandae mollitia. Voluptate optio distinctio ratione recusandae! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sit, sed. E
    rror quis impedit doloremque voluptatem fuga veritatis, officiis quaerat accusamus nisi rem ipsam porro repellendus accusantium id temporibus ad alias?Lorem ipsum dolor sit amet consectetur adipisicing elit. V
    oluptatibus necessitatibus fugit exercitationem ipsam illum, inventore quaerat iste voluptas, blanditiis consequatur atque cumque consequuntur dolorem fuga fugiat ducimus mollitia quia pr
    ovident. Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eos numquam officia earum quidem adipisci. Distinctio recusandae quibusdam mollitia molestias aliquid, obcaecati architecto
     delectus illo ut corrupti quis similique fugit tempore! Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis esse porro voluptas cum, accusantium sint libero in officiis vel nesciunt
      sit cumque ea repudiandae mollitia. Voluptate optio distinctio ratione recusandae! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sit, sed. E
    rror quis impedit doloremque voluptatem fuga veritatis, officiis quaerat accusamus nisi rem ipsam porro repellendus accusantium id temporibus ad alias?</p>
  <h4 id="scrollspyHeading5">Fifth heading</h4>
  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. V
    oluptatibus necessitatibus fugit exercitationem ipsam illum, inventore quaerat iste voluptas, blanditiis consequatur atque cumque consequuntur dolorem fuga fugiat ducimus mollitia quia pr
    ovident. Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eos numquam officia earum quidem adipisci. Distinctio recusandae quibusdam mollitia molestias aliquid, obcaecati architecto
     delectus illo ut corrupti quis similique fugit tempore! Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis esse porro voluptas cum, accusantium sint libero in officiis vel nesciunt
      sit cumque ea repudiandae mollitia. Voluptate optio distinctio ratione recusandae! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sit, sed. E
    rror quis impedit doloremque voluptatem fuga veritatis, officiis quaerat accusamus nisi rem ipsam porro repellendus accusantium id temporibus ad alias?Lorem ipsum dolor sit amet consectetur adipisicing elit. V
    oluptatibus necessitatibus fugit exercitationem ipsam illum, inventore quaerat iste voluptas, blanditiis consequatur atque cumque consequuntur dolorem fuga fugiat ducimus mollitia quia pr
    ovident. Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eos numquam officia earum quidem adipisci. Distinctio recusandae quibusdam mollitia molestias aliquid, obcaecati architecto
     delectus illo ut corrupti quis similique fugit tempore! Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis esse porro voluptas cum, accusantium sint libero in officiis vel nesciunt
      sit cumque ea repudiandae mollitia. Voluptate optio distinctio ratione recusandae! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sit, sed. E
    rror quis impedit doloremque voluptatem fuga veritatis, officiis quaerat accusamus nisi rem ipsam porro repellendus accusantium id temporibus ad alias?Lorem ipsum dolor sit amet consectetur adipisicing elit. V
    oluptatibus necessitatibus fugit exercitationem ipsam illum, inventore quaerat iste voluptas, blanditiis consequatur atque cumque consequuntur dolorem fuga fugiat ducimus mollitia quia pr
    ovident. Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eos numquam officia earum quidem adipisci. Distinctio recusandae quibusdam mollitia molestias aliquid, obcaecati architecto
     delectus illo ut corrupti quis similique fugit tempore! Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis esse porro voluptas cum, accusantium sint libero in officiis vel nesciunt
      sit cumque ea repudiandae mollitia. Voluptate optio distinctio ratione recusandae! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sit, sed. E
    rror quis impedit doloremque voluptatem fuga veritatis, officiis quaerat accusamus nisi rem ipsam porro repellendus accusantium id temporibus ad alias?</p>
</div>

  


-->




    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>