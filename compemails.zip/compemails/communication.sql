-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : jeu. 23 nov. 2023 à 14:07
-- Version du serveur : 5.7.36
-- Version de PHP : 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `communication`
--

-- --------------------------------------------------------

--
-- Structure de la table `compemails_compte`
--

DROP TABLE IF EXISTS `compemails_compte`;
CREATE TABLE IF NOT EXISTS `compemails_compte` (
  `numCompte` int(11) NOT NULL AUTO_INCREMENT,
  `prenom` text NOT NULL,
  `nom` text NOT NULL,
  `mail` text NOT NULL,
  `mdp` text NOT NULL,
  `droit` varchar(11) NOT NULL,
  `desactive` varchar(3) NOT NULL,
  PRIMARY KEY (`numCompte`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `compemails_compte`
--

INSERT INTO `compemails_compte` (`numCompte`, `prenom`, `nom`, `mail`, `mdp`, `droit`, `desactive`) VALUES
(1, 'Nicolas', 'LONGHI', 'n@gmail.com', '$2y$10$FAMKnSofiIbF1S.77zYeFOo0a0xDuW5NWJ0mDxqU.YasE3zHUMUK2', 'super admin', 'non');

-- --------------------------------------------------------

--
-- Structure de la table `compemails_exception`
--

DROP TABLE IF EXISTS `compemails_exception`;
CREATE TABLE IF NOT EXISTS `compemails_exception` (
  `numException` int(11) NOT NULL AUTO_INCREMENT,
  `idLI` int(11) NOT NULL,
  PRIMARY KEY (`numException`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compemails_historique`
--

DROP TABLE IF EXISTS `compemails_historique`;
CREATE TABLE IF NOT EXISTS `compemails_historique` (
  `numHistorique` int(11) NOT NULL AUTO_INCREMENT,
  `idAdel` int(11) NOT NULL,
  `dateEnvoi` datetime NOT NULL,
  `objet` text NOT NULL,
  `message` text NOT NULL,
  `adresseMail` text NOT NULL,
  PRIMARY KEY (`numHistorique`),
  KEY `idAdel` (`idAdel`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compemails_mailpre`
--

DROP TABLE IF EXISTS `compemails_mailpre`;
CREATE TABLE IF NOT EXISTS `compemails_mailpre` (
  `numMailPre` int(11) NOT NULL AUTO_INCREMENT,
  `campagne` text NOT NULL,
  `objet` text NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`numMailPre`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `compemails_mailpre`
--

INSERT INTO `compemails_mailpre` (`numMailPre`, `campagne`, `objet`, `message`) VALUES
(1, 'mailDifferent', 'Changement d\'adresse mail pour les newsletters', 'Bonjour père,\r\n\r\nActuellement, vous recevez la lettre interne sur votre adresse [[mailLI]].\r\n\r\nNous allons changer d\'outil technique, et nous allons désormais nous appuyer sur les informations contenues dans la base de la Chancellerie.\r\nL\'adresse que vous y avez est actuellement [[mailAdel]].\r\n\r\nL\'envoi d\'informations sur cette adresse vous convient-elle ?\r\n\r\nSi non, souhaitez-vous que nous demandions à la Chancellerie de remplacer votre adresse [[mailAdel]] par [[mailLI]] ?'),
(2, 'adelManquant', 'Changement d\'adresse mail pour les newsletters', 'Bonjour père,\r\n\r\nActuellement, vous recevez la lettre interne sur votre adresse [[mailLI]].\r\n\r\nNous allons changer d\'outil technique, et nous allons désormais nous appuyer sur les informations contenues dans la base de la Chancellerie.\r\nDans cette base, votre adresse est inexistante ou privée.\r\n\r\nPouvons-nous demander à la Chancellerie de renseigner l\'adresse [[mailLI]] ?');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
