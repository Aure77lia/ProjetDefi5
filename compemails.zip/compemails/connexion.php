<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Connexion</title>
    <link rel="icon" type="image/png" sizes="250x250" href="image\utilisateurIcone.png?v= <?php echo date("Y-m-d H:i:s") ?> ">
</head>
<body>
    <div class="position-absolute top-0 start-50 translate-middle-x">
        <div class="text-center">
            <h1>Connexion</h1>
            <br/><br/>
            <form action="traitement/traitementConnexion.php" method="POST">
                <div class="form-row">
                    <div class="form-group">
                        <label for="mail"><strong>Adresse mail</strong></label><input type="email" class="form-control" name="mail" id="mail">
                        <label for="mdp"><strong>Mot de passe</strong></label><input type="password" class="form-control" maxlength="40" name="mdp" id="mdp"><br/>
                        <input type="submit" value="Se connecter" class = "btn btn-secondary"/>
                    </div>
                </div>
            </form>
            <?php
                session_start();
                if (isset($_SESSION['mail']) && isset($_SESSION['droit']) && isset($_SESSION['prenom']) && isset($_SESSION['nom'])) {
                    header('Location: index.php');
                }

                if (isset($_SESSION["incorrect"])) {
                    if ($_SESSION["incorrect"]) {
                        echo "<br/><br/>
                                <div class='alert alert-warning'>
                                    <strong>Erreur !</strong> Identifiant ou mot de passe incorrect.
                                </div>";
                        $_SESSION["incorrect"] = false;
                    }
                }
                if (isset($_SESSION["remplirInfo"])) {
                    if ($_SESSION["remplirInfo"]) {
                        echo "<br/><br/>
                                <div class='alert alert-warning'>
                                    <strong>Erreur !</strong> Vous devez remplir toutes les informations.
                                </div>";
                        $_SESSION["remplirInfo"] = false;
                    }
                }
                if (isset($_SESSION["compteDesactive"])) {
                    if ($_SESSION["compteDesactive"]) {
                        echo "<br/><br/>
                                <div class='alert alert-warning'>
                                    <strong>Erreur !</strong> Votre compte est désactivé.
                                </div>";
                        $_SESSION["compteDesactive"] = false;
                    }
                }
            ?>
    
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
</body>
</html>
