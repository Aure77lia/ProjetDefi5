<?php

    function suppAccents($string) {
        if (!preg_match('/[\x80-\xff]/', $string))
            return $string;

        $chars = array(
            // Decompositions for Latin-1 Supplement
            chr(195).chr(128) => 'A', chr(195).chr(129) => 'A',
            chr(195).chr(130) => 'A', chr(195).chr(131) => 'A',
            chr(195).chr(132) => 'A', chr(195).chr(133) => 'A',
            chr(195).chr(135) => 'C', chr(195).chr(136) => 'E',
            chr(195).chr(137) => 'E', chr(195).chr(138) => 'E',
            chr(195).chr(139) => 'E', chr(195).chr(140) => 'I',
            chr(195).chr(141) => 'I', chr(195).chr(142) => 'I',
            chr(195).chr(143) => 'I', chr(195).chr(145) => 'N',
            chr(195).chr(146) => 'O', chr(195).chr(147) => 'O',
            chr(195).chr(148) => 'O', chr(195).chr(149) => 'O',
            chr(195).chr(150) => 'O', chr(195).chr(153) => 'U',
            chr(195).chr(154) => 'U', chr(195).chr(155) => 'U',
            chr(195).chr(156) => 'U', chr(195).chr(157) => 'Y',
            chr(195).chr(159) => 's', chr(195).chr(160) => 'a',
            chr(195).chr(161) => 'a', chr(195).chr(162) => 'a',
            chr(195).chr(163) => 'a', chr(195).chr(164) => 'a',
            chr(195).chr(165) => 'a', chr(195).chr(167) => 'c',
            chr(195).chr(168) => 'e', chr(195).chr(169) => 'e',
            chr(195).chr(170) => 'e', chr(195).chr(171) => 'e',
            chr(195).chr(172) => 'i', chr(195).chr(173) => 'i',
            chr(195).chr(174) => 'i', chr(195).chr(175) => 'i',
            chr(195).chr(177) => 'n', chr(195).chr(178) => 'o',
            chr(195).chr(179) => 'o', chr(195).chr(180) => 'o',
            chr(195).chr(181) => 'o', chr(195).chr(182) => 'o',
            chr(195).chr(182) => 'o', chr(195).chr(185) => 'u',
            chr(195).chr(186) => 'u', chr(195).chr(187) => 'u',
            chr(195).chr(188) => 'u', chr(195).chr(189) => 'y',
            chr(195).chr(191) => 'y',
            // Decompositions for Latin Extended-A
            chr(196).chr(128) => 'A', chr(196).chr(129) => 'a',
            chr(196).chr(130) => 'A', chr(196).chr(131) => 'a',
            chr(196).chr(132) => 'A', chr(196).chr(133) => 'a',
            chr(196).chr(134) => 'C', chr(196).chr(135) => 'c',
            chr(196).chr(136) => 'C', chr(196).chr(137) => 'c',
            chr(196).chr(138) => 'C', chr(196).chr(139) => 'c',
            chr(196).chr(140) => 'C', chr(196).chr(141) => 'c',
            chr(196).chr(142) => 'D', chr(196).chr(143) => 'd',
            chr(196).chr(144) => 'D', chr(196).chr(145) => 'd',
            chr(196).chr(146) => 'E', chr(196).chr(147) => 'e',
            chr(196).chr(148) => 'E', chr(196).chr(149) => 'e',
            chr(196).chr(150) => 'E', chr(196).chr(151) => 'e',
            chr(196).chr(152) => 'E', chr(196).chr(153) => 'e',
            chr(196).chr(154) => 'E', chr(196).chr(155) => 'e',
            chr(196).chr(156) => 'G', chr(196).chr(157) => 'g',
            chr(196).chr(158) => 'G', chr(196).chr(159) => 'g',
            chr(196).chr(160) => 'G', chr(196).chr(161) => 'g',
            chr(196).chr(162) => 'G', chr(196).chr(163) => 'g',
            chr(196).chr(164) => 'H', chr(196).chr(165) => 'h',
            chr(196).chr(166) => 'H', chr(196).chr(167) => 'h',
            chr(196).chr(168) => 'I', chr(196).chr(169) => 'i',
            chr(196).chr(170) => 'I', chr(196).chr(171) => 'i',
            chr(196).chr(172) => 'I', chr(196).chr(173) => 'i',
            chr(196).chr(174) => 'I', chr(196).chr(175) => 'i',
            chr(196).chr(176) => 'I', chr(196).chr(177) => 'i',
            chr(196).chr(178) => 'IJ',chr(196).chr(179) => 'ij',
            chr(196).chr(180) => 'J', chr(196).chr(181) => 'j',
            chr(196).chr(182) => 'K', chr(196).chr(183) => 'k',
            chr(196).chr(184) => 'k', chr(196).chr(185) => 'L',
            chr(196).chr(186) => 'l', chr(196).chr(187) => 'L',
            chr(196).chr(188) => 'l', chr(196).chr(189) => 'L',
            chr(196).chr(190) => 'l', chr(196).chr(191) => 'L',
            chr(197).chr(128) => 'l', chr(197).chr(129) => 'L',
            chr(197).chr(130) => 'l', chr(197).chr(131) => 'N',
            chr(197).chr(132) => 'n', chr(197).chr(133) => 'N',
            chr(197).chr(134) => 'n', chr(197).chr(135) => 'N',
            chr(197).chr(136) => 'n', chr(197).chr(137) => 'N',
            chr(197).chr(138) => 'n', chr(197).chr(139) => 'N',
            chr(197).chr(140) => 'O', chr(197).chr(141) => 'o',
            chr(197).chr(142) => 'O', chr(197).chr(143) => 'o',
            chr(197).chr(144) => 'O', chr(197).chr(145) => 'o',
            chr(197).chr(146) => 'OE',chr(197).chr(147) => 'oe',
            chr(197).chr(148) => 'R',chr(197).chr(149) => 'r',
            chr(197).chr(150) => 'R',chr(197).chr(151) => 'r',
            chr(197).chr(152) => 'R',chr(197).chr(153) => 'r',
            chr(197).chr(154) => 'S',chr(197).chr(155) => 's',
            chr(197).chr(156) => 'S',chr(197).chr(157) => 's',
            chr(197).chr(158) => 'S',chr(197).chr(159) => 's',
            chr(197).chr(160) => 'S', chr(197).chr(161) => 's',
            chr(197).chr(162) => 'T', chr(197).chr(163) => 't',
            chr(197).chr(164) => 'T', chr(197).chr(165) => 't',
            chr(197).chr(166) => 'T', chr(197).chr(167) => 't',
            chr(197).chr(168) => 'U', chr(197).chr(169) => 'u',
            chr(197).chr(170) => 'U', chr(197).chr(171) => 'u',
            chr(197).chr(172) => 'U', chr(197).chr(173) => 'u',
            chr(197).chr(174) => 'U', chr(197).chr(175) => 'u',
            chr(197).chr(176) => 'U', chr(197).chr(177) => 'u',
            chr(197).chr(178) => 'U', chr(197).chr(179) => 'u',
            chr(197).chr(180) => 'W', chr(197).chr(181) => 'w',
            chr(197).chr(182) => 'Y', chr(197).chr(183) => 'y',
            chr(197).chr(184) => 'Y', chr(197).chr(185) => 'Z',
            chr(197).chr(186) => 'z', chr(197).chr(187) => 'Z',
            chr(197).chr(188) => 'z', chr(197).chr(189) => 'Z',
            chr(197).chr(190) => 'z', chr(197).chr(191) => 's'
        );

        $string = strtr($string, $chars);

        return $string;
    }

    function uniformiser($string) {
        $string = suppAccents($string);
        $string = strtolower($string);
        return $string;
    }

    function csvToArray($csvFile){
        $file_to_read = fopen($csvFile, 'r');

        while (!feof($file_to_read) ) {
            $lines[] = fgetcsv($file_to_read, 1000, ',');

        }
        fclose($file_to_read);
        return $lines;
    }

    function fichierCache() {
        if (file_exists('cache') == false) {
            mkdir('cache');
        }
        if (file_exists('cache/profil.json') == false) {
            fopen('cache/profil.json', "a") ;
        }
        if (file_exists('cache/statut.json') == false) {
            fopen('cache/statut.json', "a") ;
        }
        if (file_exists('cache/tabProfilCorrect.json') == false) {
            fopen('cache/tabProfilCorrect.json', "a") ;
        }
        if (file_exists('cache/tabMailDiff.json') == false) {
            fopen('cache/tabMailDiff.json', "a") ;
        }
        if (file_exists('cache/tabAdelManquant.json') == false) {
            fopen('cache/tabAdelManquant.json', "a") ;
        }
        if (file_exists('cache/tabLIManquant.json') == false) {
            fopen('cache/tabLIManquant.json', "a") ;
        }
        if (file_exists('cache/tabLIManquantAdelManquant.json') == false) {
            fopen('cache/tabLIManquantAdelManquant.json', "a") ;
        }
        if (file_exists('cache/tabProfilOrphelin.json') == false) {
            fopen('cache/tabProfilOrphelin.json', "a") ;
        }
    }

    function recupHistorique($idAdel, $historique) {
        $msg = null;
        if (sizeof($historique) != 0) {
            foreach ($historique as $ligne) {
                if ($ligne['idAdel'] == $idAdel) {
                    $msg .= '<strong><h4>• ' . $ligne['dateEnvoi'] . '</h4></strong><br/>
                    <strong>Message envoyé via : </strong>' . $ligne['adresseMail'] . '<br/>
                    <strong>Objet : </strong>' . $ligne['objet'] . '<br/>
                    <strong>Message : </strong>' . $ligne['message'] . '<br/><br/><br/><br/>
                    ';
                }
            }
        }
        return $msg;
    }

    function ajouterModalMail($idModalMail, $prenom, $nom, $mailX, $mailY = null, $idAdel, $historique, $mailPre, $i) { //Mail X = Mail LI & Mail Y = Mail Adel
        $adresseMail = '';
        $objet = '';
        $msg = '';
        $campagne = '';
        $msgSuivi = recupHistorique($idAdel, $historique);

        if ($msgSuivi == '') {
            $msgSuivi = '<div class="text-center w-100 p-3">Aucun suivi n’est disponible</div>';
        }

        if ($mailY == null) {
            $objet = $mailPre[1]['objet'];
            $objet = str_replace("[[mailLI]]", $mailX, $objet);
            $adresseMail = $mailX;
            $campagne = $mailPre[1]['campagne'];
            $msg = $mailPre[1]['message'];
            $msg = str_replace("[[mailLI]]", $mailX, $msg);
        }
        else {
            $objet = $mailPre[0]['objet'];
            $objet = str_replace("[[mailAdel]]", $mailY, $objet);
            $objet = str_replace("[[mailLI]]", $mailX, $objet);
            $adresseMail = $mailX;
            $campagne = $mailPre[0]['campagne'];
            $msg = $mailPre[0]['message'];
            $msg = str_replace("[[mailLI]]", $mailX, $msg);
            $msg = str_replace("[[mailAdel]]", $mailY, $msg);
        }
        $string = '<div class="modal fade" id="' . $idModalMail . '" tabindex="-1" aria-labelledby="modalLabel' . $i . '" aria-hidden="true">
                        <div class="modal-dialog modal-xl">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="modalLabel' . $i . '">' . $prenom . ' ' . $nom . '</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="row">
                                        <div class="col-6 align-items-center">
                                            ' . $msgSuivi . '
                                        </div>
                                        <div class="col-6">
                                            <form action="traitement/traitementEnvoyerMail.php" method="POST">
                                                <div class="form-group">
                                                    <input type="hidden" class="form-control" name="idAdel" id="idAdel' . $i . '" value="' . $idAdel . '">
                                                    <input type="hidden" class="form-control" name="adresseMail" id="adresseMail' . $i . '" value="' . $adresseMail . '">
                                                    <input type="hidden" class="form-control" name="campagne" id="campagne' . $i . '" value="' . $campagne . '">
                                                    <label for="mailEnvoiAffichage' . $i . '"><strong>Destinataire</strong></label>
                                                    <input class="form-control" name="mailEnvoiAffichage" id="mailEnvoiAffichage' . $i . '" type="text" value="' . $adresseMail . '" disabled readonly>
                                                    <label for="objet' . $i . '"><strong>Objet</strong></label>
                                                    <input type="text" class="form-control" name="objet" id="objet' . $i . '" value="' . $objet . '">
                                                </div>
                                                <div class="form-group">
                                                    <label for="contenuMail' . $i . '"><strong>Contenu du mail</strong></label>
                                                    <textarea class="form-control" name="contenuMail" id="contenuMail' . $i . '" rows="18">' . $msg . '</textarea>
                                                </div>
                                                <br/>
                                                <div class="form-group text-end">
                                                    <input type="submit" class="btn btn-secondary" value="Envoyer le mail">
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>';
        return $string;
    }

    function ajouterModalSuivi($idModalSuivi, $idAdel, $historique, $suivi = null, $prenom = null, $nom = null, $i) {
        if ($suivi == null) {
            $msg = recupHistorique($idAdel, $historique);
        }
        else {
            $msg = $suivi;
        }
        $entete = 'Suivi';
        if ($prenom != '' || $nom != '') {
            $entete = $prenom . ' ' . $nom;
        }
        
        if ($msg == null) {
            $msg = "<div class='align-middle'>Aucun suivi n'est disponible</div>";
        }

        $string = '<div class="modal fade" id="' . $idModalSuivi . '" tabindex="-1" aria-labelledby="modalLabel' . $i . '" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="modalLabel' . $i . '">' . $entete . '</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    ' . $msg . '
                                </div>
                                <div class="modal-footer">
                                    <button class="btn btn-secondary" data-bs-dismiss="modal" aria-label="Close">Fermer</button>
                                </div>
                            </div>
                        </div>
                    </div>';
        return $string;
    }

    function ajouterStatut($statut, $mail) {
        $retour = '<div class="text-center"><i class="fa-solid fa-xmark"></i></div>';
        foreach ($statut as $ligne) {
            if ($ligne[1] == $mail) {
                if ($ligne[0] == 'processed') {
                    $retour = ' <div data-bs-toggle="tooltip" class="text-center" title="En attente">
                                    <i class="fa-solid fa-circle fa-2xl" style="color: #8085E9; cursor: pointer"></i>
                                </div>';
                }
                elseif ($ligne[0] == 'queued') {
                    $retour = ' <div data-bs-toggle="tooltip" class="text-center" title="En attente">
                                    <i class="fa-solid fa-circle fa-2xl" style="color: #8085E9; cursor: pointer"></i>
                                </div>';
                }
                elseif ($ligne[0] == 'sent') {
                    $retour = ' <div data-bs-toggle="tooltip" class="text-center" title="Délivré">
                                    <i class="fa-solid fa-circle fa-2xl" style="color: #BABABA; cursor: pointer"></i>
                                </div>';
                }
                elseif ($ligne[0] == 'opened') {
                    $retour = ' <div data-bs-toggle="tooltip" class="text-center" title="Ouvert">
                                    <i class="fa-solid fa-circle fa-2xl" style="color: #7DD221; cursor: pointer"></i>
                                </div>';
                }
                elseif ($ligne[0] == 'clicked') {
                    $retour = ' <div data-bs-toggle="tooltip" class="text-center" title="Cliqué">
                                    <i class="fa-solid fa-circle fa-2xl" style="color: #76B233; cursor: pointer"></i>
                                </div>';
                }
                elseif ($ligne[0] == 'bounce') {
                    $retour = ' <div data-bs-toggle="tooltip" class="text-center" title="Renvoyé">
                                    <i class="fa-solid fa-circle fa-2xl" style="color: #8C8C8C; cursor: pointer"></i>
                                </div>';
                }
                elseif ($ligne[0] == 'spam') {
                    $retour = ' <div data-bs-toggle="tooltip" class="text-center" title="Spam">
                                    <i class="fa-solid fa-circle fa-2xl" style="color: #CC0B24; cursor: pointer"></i>
                                </div>';
                }
                elseif ($ligne[0] == 'unsub') {
                    $retour = ' <div data-bs-toggle="tooltip" class="text-center" title="Désabonné">
                                    <i class="fa-solid fa-circle fa-2xl" style="color: #23B2FB; cursor: pointer"></i>
                                </div>';
                }
                elseif ($ligne[0] == 'blocked') {
                    $retour = ' <div data-bs-toggle="tooltip" class="text-center" title="Bloqué">
                                    <i class="fa-solid fa-circle fa-2xl" style="color: #000000; cursor: pointer"></i>
                                </div>';
                }
                elseif ($ligne[0] == 'hardbounced') {
                    $retour = ' <div data-bs-toggle="tooltip" class="text-center" title="Erreur permanente">
                                    <i class="fa-solid fa-circle fa-2xl" style="color: #FF8A6B; cursor: pointer"></i>
                                </div>';
                }
                elseif ($ligne[0] == 'softbounced') {
                    $retour = ' <div data-bs-toggle="tooltip" class="text-center" title="Erreur temporaire">
                                    <i class="fa-solid fa-circle fa-2xl" style="color: #FFBC97; cursor: pointer"></i>
                                </div>';
                }
                elseif ($ligne[0] == 'deferred') {
                    $retour = ' <div data-bs-toggle="tooltip" class="text-center" title="Différé">
                                    <i class="fa-solid fa-circle fa-2xl" style="color: red; cursor: pointer"></i>
                                </div>';
                }
                unset($ligne);
            }
        }
        return $retour;
    }

    function verifierException($idLI, $exception) {
        $retour = 'visible';
        if (sizeof($exception) != 0) {
            foreach ($exception as $ligne) {
                if ($ligne['idLI'] == $idLI) {
                    $retour = 'cache';
                    break;
                }
            }
        }
        return $retour;
    }

    function listeFichier($bdd, $valeur) { //Renvoi le nom du fichier le plus recent, le plus vieux, etc (en fonction de $valeur)
        $retour = null;
        $tableDateFichier = array();
        if ($bdd == 'LI') {
            if (is_dir('/home/communication/comm.dioceseparis.fr/www/compemails/cacheBDD/')) {
                if ($dh = opendir('/home/communication/comm.dioceseparis.fr/www/compemails/cacheBDD/')){
                    while (($fichier = readdir($dh)) !== false){
                        if ($fichier != '.' && $fichier != '..' && strpos($fichier, '.json')) {
                            $datefichier = str_replace(".json", "", $fichier);
                            $datefichier = str_replace("LI_", "", $datefichier);
                            array_push($tableDateFichier, $datefichier);
                        }
                    }
                    closedir($dh);
                }
            }
        }
        elseif ($bdd == 'Adel') {
            if (is_dir('/home/communication/comm.dioceseparis.fr/www/compemails/cacheBDD/')) {
                if ($dh = opendir('/home/communication/comm.dioceseparis.fr/www/compemails/cacheBDD/')){
                    while (($fichier = readdir($dh)) !== false){
                        if ($fichier != '.' && $fichier != '..' && strpos($fichier, '.csv')) {
                            $datefichier = str_replace(".csv", "", $fichier);
                            $datefichier = str_replace("Adel_", "", $datefichier);
                            array_push($tableDateFichier, $datefichier);
                        }
                    }
                    closedir($dh);
                }
            }
        }

        if ($valeur == 4) { // Le plus récent
            $retour = max($tableDateFichier);
        }
        elseif ($valeur == 3) { // Le deuxième plus récent
            array_splice($tableDateFichier, array_search(max($tableDateFichier), $tableDateFichier), 1);
            $retour = max($tableDateFichier);
        }
        elseif ($valeur == 2) { // Le deuxième plus vieux
            array_splice($tableDateFichier, array_search(min($tableDateFichier), $tableDateFichier), 1);
            $retour = min($tableDateFichier);
        }
        elseif ($valeur == 1) { // Le plus vieux
            $retour = min($tableDateFichier);
        }

        if ($bdd == 'LI') {
            $retour = "/home/communication/comm.dioceseparis.fr/www/compemails/cacheBDD/LI_" . $retour . ".json";
        }
        elseif ($bdd == 'Adel') {
            $retour = "/home/communication/comm.dioceseparis.fr/www/compemails/cacheBDD/Adel_" . $retour . ".csv";
        }
        return $retour;
    }


    function ajouterSelectLI() {
        $retour = '<select name="valeurLI" class="form-select" id="valeurLI">';
        $i = 1;
        $tableDateFichier = array();
        if (is_dir('cacheBDD/')) {
            if ($dh = opendir('cacheBDD/')){
                while (($fichier = readdir($dh)) !== false){
                    if ($fichier != '.' && $fichier != '..' && strpos($fichier, '.json')) {
                        $datefichier = str_replace(".json", "", $fichier);
                        $datefichier = str_replace("LI_", "", $datefichier);
                        array_push($tableDateFichier, date("d/m/Y à H\hi", $datefichier));
                    }
                }
                closedir($dh);
            }
        }
        sort($tableDateFichier);
        foreach ($tableDateFichier as $ligne) {
            if ($i == sizeof($tableDateFichier)) {
                $retour .= '<option value="' . $i . '" selected>' . $ligne . '</option>';
            }
            else {
                $retour .= '<option value="' . $i . '">' . $ligne . '</option>';
            }
            $i++;
        }
        $retour .= '</select>';
        return $retour;
    }

    function ajouterSelectAdel() {
        $retour = '<select name="valeurAdel" class="form-select" id="valeurAdel">';
        $i = 1;
        $tableDateFichier = array();
        if (is_dir('cacheBDD/')) {
            if ($dh = opendir('cacheBDD/')){
                while (($fichier = readdir($dh)) !== false){
                    if ($fichier != '.' && $fichier != '..' && strpos($fichier, '.csv')) {
                        $datefichier = str_replace(".csv", "", $fichier);
                        $datefichier = str_replace("Adel_", "", $datefichier);
                        array_push($tableDateFichier, date("d/m/Y à H\hi", $datefichier));
                    }
                }
                closedir($dh);
            }
        }
        sort($tableDateFichier);
        foreach ($tableDateFichier as $ligne) {
            if ($i == sizeof($tableDateFichier)) {
                $retour .= '<option value="' . $i . '" selected>' . $ligne . '</option>';
            }
            else {
                $retour .= '<option value="' . $i . '">' . $ligne . '</option>';
            }
            $i++;
        }
        $retour .= '</select>';
        return $retour;
    }

    function recupDateFichier($fichier, $type) {
        if ($type == "LI") {
            $fichier = str_replace(".json", "", $fichier);
            $fichier = str_replace("/home/communication/comm.dioceseparis.fr/www/compemails/cacheBDD/LI_", "", $fichier);
        }
        elseif ($type == "Adel") {
            $fichier = str_replace(".csv", "", $fichier);
            $fichier = str_replace("/home/communication/comm.dioceseparis.fr/www/compemails/cacheBDD/Adel_", "", $fichier);
        }
        return $fichier;
    }


    function traitement($fichierLI, $fichierAdel) {

        $profil = array(array(), array($fichierLI, recupDateFichier($fichierLI, "LI"), $fichierAdel, recupDateFichier($fichierAdel, "Adel")));
        $modals = '';

        $nbCorrect = 0;
        $nbAdelManquant = 0;
        $nbEmailDiff = 0;
        $nbLIMaquant = 0;
        $nbLIMaquantAdelManquant = 0;
        $nbLIOrphelin = 0;
        
        $tabProfilCorrect = array();
        $tabAdelManquant = array();
        $tabMailDiff = array();
        $tabLIManquant = array();
        $tabLIManquantAdelManquant = array();
        $tabProfilOrphelin = array();

        $cheminCacheProfil = '/home/communication/comm.dioceseparis.fr/www/compemails/cache/profil.json';
        $cheminCacheTabProfilCorrect = '/home/communication/comm.dioceseparis.fr/www/compemails/cache/tabProfilCorrect.json';
        $cheminCacheTabMailDiff = '/home/communication/comm.dioceseparis.fr/www/compemails/cache/tabMailDiff.json';
        $cheminCacheTabAdelManquant = '/home/communication/comm.dioceseparis.fr/www/compemails/cache/tabAdelManquant.json';
        $cheminCacheTabLIManquant = '/home/communication/comm.dioceseparis.fr/www/compemails/cache/tabLIManquant.json';
        $cheminCacheTabLIManquantAdelManquant = '/home/communication/comm.dioceseparis.fr/www/compemails/cache/tabLIManquantAdelManquant.json';
        $cheminCacheTabProfilOrphelin = '/home/communication/comm.dioceseparis.fr/www/compemails/cache/tabProfilOrphelin.json';

        $erreur = false;

        //Importation de BDD LI
        $bddLInterne = array();
        if (file_exists($fichierLI) == false) {
            $erreur = true;
        }
        else {
            $intermediaire = file_get_contents($fichierLI);
            $intermediaire = json_decode($intermediaire, true);
            //Suppression des données inutiles BDD LI
            for ($i = 0 ; $i < sizeof($intermediaire) ; $i++) {
                $bddLInterne[$i]['id'] = $intermediaire[$i]['id'];
                $bddLInterne[$i]['prenom'] = $intermediaire[$i]['prenom'];
                $bddLInterne[$i]['nom'] = $intermediaire[$i]['nom'];
                $bddLInterne[$i]['email'] = $intermediaire[$i]['email'];
            }
        }


        //Importation de BDD Adel
        $bddAdel = array();
        if (file_exists($fichierAdel) == false) {
            $erreur = true;
        }
        else {
            $bddAdel = csvToArray($fichierAdel);
            //Suppression des données inutiles BDD Adel
            array_splice($bddAdel, 0, 1);
            array_splice($bddAdel, sizeof($bddAdel) - 1, 1);
        }
        
        if ($erreur == false) {
            //Boucle 1 - Adel est la BDD principale
            for ($i = 0 ; $i < sizeof($bddAdel); $i++) {
                //Uniformiser + particule + simplifier
                $idAdel = '<strong>' . $bddAdel[$i][0] . '</strong>';
                $nomAdel = uniformiser($bddAdel[$i][1]);
                if (strtolower($bddAdel[$i][3]) == 'de') {
                    $nomAdel = 'de ' . $nomAdel;
                }
                elseif ($bddAdel[$i][3] == "d'" || $bddAdel[$i][3] == "d’" ||$bddAdel[$i][3] == "d " || $bddAdel[$i][3] == "d") {
                    $nomAdel = "d'" . $nomAdel;
                }
                elseif ($bddAdel[$i][3] == "de la" || $bddAdel[$i][3] == "dela" || $bddAdel[$i][3] == "de la ") {
                    $nomAdel = "de la " . $nomAdel;
                }
                elseif ($bddAdel[$i][3] == "du" || $bddAdel[$i][3] == "du ") {
                    $nomAdel = "du " . $nomAdel;
                }
                elseif ($bddAdel[$i][3] == "de l'" || $bddAdel[$i][3] == "de l’" || $bddAdel[$i][3] == "de l " || $bddAdel[$i][3] == "de l" || $bddAdel[$i][3] == "del" || $bddAdel[$i][3] == "del'" || $bddAdel[$i][3] == "del’" || $bddAdel[$i][3] == "del ") {
                    $nomAdel = "de l'" . $nomAdel;
                }
                $prenomAdel = uniformiser($bddAdel[$i][2]);
                $mailAdel = strtolower($bddAdel[$i][4]);
                $mailAdelBureau = strtolower($bddAdel[$i][5]);
                $ligneMailAdelBureau = '<td><i class="fa-solid fa-circle-check" style="color:green"></i>&nbsp;<a style="cursor: pointer;" class="text-decoration-none" id="' . $mailAdelBureau . '" onClick="copier(this)">' . $mailAdelBureau . '</a></td>';
                if ($mailAdelBureau == '') {
                    $ligneMailAdelBureau = '<td><div class="text-center"><i class="fa-solid fa-xmark"></i></div></td>';
                }
                elseif ($mailAdel != $mailAdelBureau) {
                    $ligneMailAdelBureau = '<td><i class="fa-solid fa-circle-xmark" style="color:red">&nbsp;</i><a style="cursor: pointer;" class="text-decoration-none" id="' . $mailAdelBureau . '" onClick="copier(this)">' . $mailAdelBureau . '</a></td>';
                }
                
                $compteur = 0;

                //Boucle pour trouver les profils avec les mails identiques / différents / manquants dans Adel (Si, et seulement si, le profil existe aussi dans LI) 
                for ($j = 0 ; $j < sizeof($bddLInterne) ; $j++) {
                    //Uniformiser + simplifier
                    $nomLI = uniformiser($bddLInterne[$j]['nom']);
                    $prenomLI = uniformiser($bddLInterne[$j]['prenom']);
                    $mailLI = strtolower($bddLInterne[$j]['email']);
                    $idModalMail = 'modalMail' . $i;
                    $idModalSuivi = 'modalSuivi' . $i;
                    
                    //Si le profil est identique (nom et prénom)
                    if (($nomLI == $nomAdel && $prenomLI == $prenomAdel) || $mailAdel == $mailLI) {
                        if ($mailAdel == $mailLI) { //Code erreur : 1 (Profil correct)
                            array_push($profil[0], array($bddAdel[$i][0], $bddAdel[$i][2], strtoUpper($nomAdel), $mailAdel, $mailAdelBureau, $mailLI, 1));
                            array_push($tabProfilCorrect, array($prenomAdel, $nomAdel, $mailLI, $mailAdel));
                        }
                        elseif ($mailAdel == null || $mailAdel == 'null' || $mailAdel == 'NULL' || $mailAdel == '') { //Code erreur : 3 (Adel manquant)
                            array_push($profil[0], array($bddAdel[$i][0], $bddAdel[$i][2], strtoUpper($nomAdel), $mailAdel, $mailAdelBureau, $mailLI, 3));
                            array_push($tabAdelManquant, array($prenomAdel, $nomAdel, $mailLI));
                        }
                        elseif ($mailAdel != $mailLI) { //Code erreur : 2 (Mails différents)
                            array_push($profil[0], array($bddAdel[$i][0], $bddAdel[$i][2], strtoUpper($nomAdel), $mailAdel, $mailAdelBureau, $mailLI, 2));
                            array_push($tabMailDiff, array($prenomAdel, $nomAdel, $mailAdel, $mailLI));
                        }
                    }
                    else {
                        $compteur++; //Pour compter le nombre de profil qui ne correspondent pas entre eux
                    }
                }
                //S'il y a autant de profils qui ne correspondent pas que de profils totals dans la BDD LI, alors le profil en cours (Adel) n'est pas répertorié dans la BDD LI
                if ($compteur == sizeof($bddLInterne)) {
                    if ($mailAdel == null || $mailAdel == 'null' || $mailAdel == '') { //Code erreur : 5 (LI manquant et Adel manquant)
                        array_push($profil[0], array($bddAdel[$i][0], $bddAdel[$i][2], strtoUpper($nomAdel), $mailAdel, $mailAdelBureau, $mailLI, 5));
                        array_push($tabLIManquantAdelManquant, array($prenomAdel, $nomAdel));
                    }
                    else { //Code erreur : 4 (LI manquant)
                        array_push($profil[0], array($bddAdel[$i][0], $bddAdel[$i][2], $bddAdel[$i][1], $mailAdel, $mailAdelBureau, $mailLI, 4));
                        array_push($tabLIManquant, array($prenomAdel, $nomAdel, $mailAdel));
                    }
                }
            }

            //Boucle 2 - LI est la BDD principale
            for ($j = 0 ; $j < sizeof($bddLInterne) ; $j++) {
                //Uniformiser + simplifier
                $idLI = uniformiser($bddLInterne[$j]['id']);
                $nomLI = uniformiser($bddLInterne[$j]['nom']);
                $prenomLI = uniformiser($bddLInterne[$j]['prenom']);
                $mailLI = strtolower($bddLInterne[$j]['email']);

                $compteur = 0;
                //Boucle pour trouver les profils orphelins de LI
                for ($i = 0 ; $i < sizeof($bddAdel); $i++) {
                    //Uniformiser + particule + simplifier
                    $nomAdel = uniformiser($bddAdel[$i][1]);
                    if (strtolower($bddAdel[$i][3]) == 'de') {
                        $nomAdel = 'de ' . $nomAdel;
                    }
                    elseif ($bddAdel[$i][3] == "d'" || $bddAdel[$i][3] == "d’" || $bddAdel[$i][3] == "d " || $bddAdel[$i][3] == "d") {
                        $nomAdel = "d'" . $nomAdel;
                    }
                    elseif ($bddAdel[$i][3] == "de la" || $bddAdel[$i][3] == "dela" || $bddAdel[$i][3] == "de la ") {
                        $nomAdel = "de la " . $nomAdel;
                    }
                    elseif ($bddAdel[$i][3] == "du" || $bddAdel[$i][3] == "du ") {
                        $nomAdel = "du " . $nomAdel;
                    }
                    elseif ($bddAdel[$i][3] == "de l'" || $bddAdel[$i][3] == "de l’" || $bddAdel[$i][3] == "de l " || $bddAdel[$i][3] == "de l" || $bddAdel[$i][3] == "del" || $bddAdel[$i][3] == "del'" || $bddAdel[$i][3] == "del’" || $bddAdel[$i][3] == "del ") {
                        $nomAdel = "de l'" . $nomAdel;
                    }
                    $prenomAdel = uniformiser($bddAdel[$i][2]);
                    $mailAdel = strtolower($bddAdel[$i][4]);


                    //Si le profil est identique (nom et prénom)
                    if (($nomLI == $nomAdel && $prenomLI == $prenomAdel) || $mailAdel == $mailLI) {

                    }
                    else {
                        $compteur++; //Pour compter le nombre de profil qui ne correspondent pas entre eux
                    }
                }
                
                //S'il y a autant de profils qui ne correspondent pas que de profils totals dans la BDD Adel, alors le profil en cours (LI) n'est pas répertorié dans la BDD Adel
                if ($compteur == sizeof($bddAdel)) { //Code erreur : 6 (LI orphelin)
                    array_push($profil[0], array($idLI, $bddLInterne[$j]['prenom'], $bddLInterne[$j]['nom'], "", "", $mailLI, 6));
                    array_push($tabProfilOrphelin, array($prenomLI, $nomLI, $mailLI));
                }
            }

            $tabJSON = json_encode($profil);
            file_put_contents($cheminCacheProfil, $tabJSON);

            $tabJSON = json_encode($tabProfilCorrect);
            file_put_contents($cheminCacheTabProfilCorrect, $tabJSON);
            $tabJSON = json_encode($tabMailDiff);
            file_put_contents($cheminCacheTabMailDiff, $tabJSON);
            $tabJSON = json_encode($tabAdelManquant);
            file_put_contents($cheminCacheTabAdelManquant, $tabJSON);
            $tabJSON = json_encode($tabLIManquant);
            file_put_contents($cheminCacheTabLIManquant, $tabJSON);
            $tabJSON = json_encode($tabLIManquantAdelManquant);
            file_put_contents($cheminCacheTabLIManquantAdelManquant, $tabJSON);
            $tabJSON = json_encode($tabProfilOrphelin);
            file_put_contents($cheminCacheTabProfilOrphelin, $tabJSON);
        }
        return $erreur;
    }

?>