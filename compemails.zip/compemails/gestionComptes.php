<?php
    require('traitement/verifConnecte.php');
    require('traitement/config.php');
    require('fonctionInterface.php');
    
    if ($droit == 'super admin') {
        $cardComptes = '';
        $comptes = requeteRecupererCompte();
        $j = 2;
        $numUnique = new DateTime();
        $numUnique = $numUnique->getTimestamp();

        $notif =' hidden';
        $msgNotif = '';
        $entete = '';

        if (isset($_SESSION["notif"]) && $_SESSION["notif"] != '') {
            if ($_SESSION["notif"] == "remplirInfo") {
                $entete = '<strong class="me-auto"><i class="bi-globe"></i><i class="fa-solid fa-circle-exclamation" style="color: red"></i> Erreur</strong>';
                $msgNotif = 'Vous devez remplir toutes les informations.';
            }
            elseif ($_SESSION["notif"] == "mdpTropCourt") {
                $entete = '<strong class="me-auto"><i class="bi-globe"></i><i class="fa-solid fa-circle-exclamation" style="color: red"></i> Erreur</strong>';
                $msgNotif = 'Le mot de passe est trop court. Celui-ci doit contenir au moins 8 caractères.';
            }
            elseif ($_SESSION["notif"] == "cree") {
                $entete = '<strong class="me-auto"><i class="bi-globe"></i><i class="fa-solid fa-circle-check" style="color: green"></i></i> Créé</strong>';
                $msgNotif = 'Le compte a bien été créé.';
            }
            elseif ($_SESSION["notif"] == "modifie") {
                $entete = '<strong class="me-auto"><i class="bi-globe"></i><i class="fa-solid fa-circle-check" style="color: green"></i></i> Modifié</strong>';
                $msgNotif = 'Le compte a bien été modifié.';
            }
            elseif ($_SESSION["notif"] == "supprime") {
                $entete = '<strong class="me-auto"><i class="bi-globe"></i><i class="fa-solid fa-circle-check" style="color: green"></i></i> Supprimé</strong>';
                $msgNotif = 'Le compte a bien été supprimé.';
            }
            elseif ($_SESSION["notif"] == "mailDejaPris") {
                $entete = '<strong class="me-auto"><i class="bi-globe"></i><i class="fa-solid fa-circle-exclamation" style="color: red"></i> Erreur</strong>';
                $msgNotif = 'L’adresse mail est déjà utilisée.';
            }
            $notif = '';
            $_SESSION["notif"] = '';
        }

        foreach ($comptes as $unCompte) {
            $desactiveActuel = '';
            $i = $unCompte['numCompte'];
            if ($unCompte['desactive'] == 'non') {
                $desactiveActuel = '
                <div class="row">
                    <div class="col-12 col-md-4">
                        <label for="statu' . $j . '"><strong>Statut</strong></label>
                    </div>
                    <div class="col-12 col-md-8">
                        <div class="input-group">
                            <div class="input-group-text" style="width: 40px"><span id="iconeStatut' . $j . '"><i class="fa-solid fa-lock-open"></i></span></div>
                            <select class="form-select" name="desactive" id="statu' . $j . '" onChange="iconeStatut(this)">
                                <option value="non" selected>Activé</option>
                                <option value="oui">Désactivé</option>
                            </select>
                        </div>
                    </div>
                </div>';
            }
            else {
                $desactiveActuel = '
                <div class="row">
                    <div class="col-12 col-md-4">
                        <label for="statu' . $j . '"><strong>Statut</strong></label>
                    </div>
                    <div class="col-12 col-md-8">
                        <div class="input-group">
                            <div class="input-group-text" style="width: 40px"><span id="iconeStatut' . $j . '"><i class="fa-solid fa-lock"></i></span></div>
                            <select class="form-select" name="desactive" id="statu' . $j . '" onChange="iconeStatut(this)">
                                <option value="non">Activé</option>
                                <option value="oui" selected>Désactivé</option>
                            </select>
                        </div>
                    </div>
                </div>';
            }
            $droitActuel = '';
            if ($unCompte['droit'] == 'super admin') {
                $droitActuel = '
                <div class="row">
                    <div class="col-12 col-md-4">
                        <label for="droit' . $j . '"><strong>Droit</strong></label>
                    </div>
                    <div class="col-12 col-md-8">
                        <div class="input-group">
                            <div class="input-group-text" style="width: 40px"><span id="iconeDroit' . $j . '"><i class="fa-solid fa-crown" style="color: #FACD03"></i></span></div>
                            <select class="form-select" name="droit" id="droit' . $j . '" onChange="iconeDroit(this)">
                                <option value="visiteur">Visiteur</option>
                                <option value="admin">Admin</option>
                                <option value="super admin" selected>Super admin</option>
                            </select>
                        </div>
                    </div>
                </div>';
            }
            elseif ($unCompte['droit'] == 'admin') {
                $droitActuel = '
                <div class="row">
                    <div class="col-12 col-md-4">
                        <label for="droit' . $j . '"><strong>Droit</strong></label>
                    </div>
                    <div class="col-12 col-md-8">
                        <div class="input-group">
                            <div class="input-group-text" style="width: 40px"><span id="iconeDroit' . $j . '"><i class="fa-solid fa-user-tie" style="color: #F11212"></i></span></div>
                            <select class="form-select" name="droit" id="droit' . $j . '" onChange="iconeDroit(this)">
                                <option value="visiteur">Visiteur</option>
                                <option value="admin" selected>Admin</option>
                                <option value="super admin">Super admin</option>
                            </select>
                        </div>
                    </div>
                </div>';
            }
            else {
                $droitActuel = '
                <div class="row">
                    <div class="col-12 col-md-4">
                        <label for="droit' . $j . '"><strong>Droit</strong></label>
                    </div>
                    <div class="col-12 col-md-8">
                        <div class="input-group">
                            <div class="input-group-text" style="width: 40px"><span id="iconeDroit' . $j . '"><i class="fa-solid fa-user-lock" style="color: #76D108"></i></span></div>
                            <select class="form-select" name="droit" id="droit' . $j . '" onChange="iconeDroit(this)">
                                <option value="visiteur" selected>Visiteur</option>
                                <option value="admin">Admin</option>
                                <option value="super admin">Super admin</option>
                            </select>
                        </div>
                    </div>
                </div>';
            }
            
            $cardComptes .= '<div class="card">
                                <div class="card-body">
                                    <p class="card-text">
                                        <form action="traitement/traitementModifier.php" method="POST">
                                            <input type="hidden" name="numCompte" value="' . $i . '"/>
                                            <div class="row">
                                                <div class="col-12 col-md-4">
                                                    <div class="row">
                                                        <div class="col-12 col-md-4">
                                                            <label for="txtPr' . $j . '"><strong>Prénom</strong></label>
                                                        </div>
                                                        <div class="col-12 col-md-8">
                                                            <input type="text" class="form-control" name="prenom" id="txtPr' . $j . '" value="' . $unCompte['prenom'] . '" placeholder="Prénom" onKeyup="modifRealise(this)" required/>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-12 col-md-4">
                                                            <label for="txtNo' . $j . '"><strong>Nom</strong></label>
                                                        </div>
                                                        <div class="col-12 col-md-8">
                                                            <input type="text" class="form-control" name="nom" id="txtNo' . $j . '" value="' . $unCompte['nom'] . '" placeholder="Nom" onKeyup="modifRealise(this)" required/>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-12 col-md-4">
                                                    <div class="row">
                                                        <div class="col-12 col-md-4">
                                                            <label for="txtMa' . $j . '"><strong>Courriel</strong></label>
                                                        </div>
                                                        <div class="col-12 col-md-8">
                                                            <input type="text" class="form-control" name="mail" id="txtMa' . $j . '" value="' . $unCompte['mail'] . '" placeholder="Courriel" onKeyup="modifRealise(this)" required/>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-12 col-md-4">
                                                            <label for="txtMd' . $j . '"><strong>Mot de passe</strong></label>
                                                        </div>
                                                        <div class="col-12 col-md-8">
                                                            <span id="txtMd">*********</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-12 col-md-4">
                                                    ' . $droitActuel . '
                                                    ' . $desactiveActuel . '
                                                </div>
                                            </div>
                                            <br/>
                                            <div class="row">
                                                <div class="text-end">
                                                    <div class="text-center btn-group" role="group" aria-label="Basic mixed styles example">
                                                            <input type="submit" class="btn btn-secondary" value="Modifier" id="btnAc' . $j . '" disabled/>
                                                        </form>
                                                        <form action="traitement/confirmationReinitialiser.php" method="POST">
                                                            <input type="hidden" name="mail" value="' . $unCompte['mail'] . '"/>
                                                            <input type="submit" class="btn btn-warning" value="Réinitialiser"/>
                                                        </form>
                                                        <form action="traitement/confirmationSupp.php" method="POST">
                                                            <input type="hidden" name="numCompte" value="' . $i . '"/>
                                                            <input type="submit" class="btn btn-danger" value="Supprimer"/>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                    </p>
                                </div>
                            </div>
                            <br/>';
            $j++;
        }

        echo'
        <!DOCTYPE html>
        <html lang="fr">
        <head>
            <meta charset="UTF-8">
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
            <link rel="stylesheet" type="text/css" href="css/bootstrapPerso.css?v=' . $numUnique . '" />
            <meta name="viewport" content="width=device-width, initial-scale=1">        
            <title>Gestion des comptes</title>
            <link rel="icon" type="image/png" sizes="250x250" href="image\utilisateurIcone.png?v=' . $numUnique . '">
        </head>
        <body>
            <h1 id="titre" class="text-center">Gestion des comptes</h1>
            <br/><br/>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-lg-2">
                        <div class="toast-container" style="position: absolute; top: 10px; left: 10px;">
                            <div class="toast fade show bg-white" id="notif"' . $notif . '>
                                <div class="toast-header">
                                    ' . $entete .'
                                </div>
                                <div class="toast-body">
                                    ' . $msgNotif . '
                                </div>
                            </div>
                        </div>
                        <div class="list-group">
                            <a href="index.php" class="list-group-item list-group-item-action list-group-item-light"><i class="fa-solid fa-table-list fa-xl"></i>&nbsp;Tableau de bord</a>
                            <a href="monCompte.php" class="list-group-item list-group-item-action list-group-item-light"><i class="fa-solid fa-user fa-xl"></i>&nbsp;Mes informations</a>
                            <a href="#" class="list-group-item list-group-item-action list-group-item-light active"><i class="fa-solid fa-list-ul fa-xl"></i>&nbsp;Gestion des comptes</a>
                            <a href="traitement/traitementDeconnexion.php" class="list-group-item list-group-item-action list-group-item-light"><i class="fa-solid fa-arrow-right-from-bracket fa-xl"></i>&nbsp;Déconnexion</a>
                        </div>
                    </div>
                    <div class="d-block d-lg-none"> 
                        <br/>
                    </div>
                    <div class="col-12 col-lg-10">
                        <div class="accordion" id="accordionExample">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingOne">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                                        <i class="fa-solid fa-user-plus fa-lg"></i>&nbsp;Créer un compte
                                    </button>
                                </h2>
                                <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <form action="traitement/traitementCreerCompte.php" method="POST">
                                            <div class="row">
                                                <div class="col-12 col-md-4">
                                                    <div class="row">
                                                        <div class="col-12 col-md-4">
                                                            <label for="txtNo1"><strong>Nom</strong></label>
                                                        </div>
                                                        <div class="col-12 col-md-8">
                                                            <input type="text" class="form-control" id="txtNo1" name="nom" onKeyup="modifRealise(this)" required/>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-12 col-md-4">
                                                            <label for="txtPr1"><strong>Prénom</strong></label>
                                                        </div>
                                                        <div class="col-12 col-md-8">
                                                            <input type="text" class="form-control" id="txtPr1" name="prenom" onKeyup="modifRealise(this)" required/>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-12 col-md-4">
                                                    <div class="row">
                                                        <div class="col-12 col-md-4">
                                                            <label for="txtMa1"><strong>Courriel</strong></label>
                                                        </div>
                                                        <div class="col-12 col-md-8">
                                                            <input type="email" class="form-control" id="txtMa1" name="mail" onKeyup="modifRealise(this)" required/>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-12 col-md-4">
                                                            <label for="txtMd1"><strong>Mot de passe</strong></label>
                                                        </div>
                                                        <div class="col-12 col-md-5">
                                                            <input type="text" id="txtMd1" name="mdp" maxlength="40" class="form-control" size="8" onKeyup="modifRealise(this)" required/>
                                                        </div>
                                                        <div class="col-12 col-md-3">
                                                            <div class="text-center btn-group" role="group" aria-label="Basic mixed styles example">
                                                                <a class="btn btn-secondary"  id="btnCopier"onClick="copierMdp()"><i class="fa-solid fa-copy"></i></a>
                                                                <a class="btn btn-secondary" id="btnRe1" onClick="modifRealise(this)"><i class="fa-solid fa-rotate"></i></a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-12 col-md-4">
                                                    <div class="row">
                                                        <div class="col-12 col-md-4">
                                                            <label for="droit1"><strong>Droit</strong></label>
                                                        </div>
                                                        <div class="col-12 col-md-8">
                                                            <div class="input-group">
                                                                <div class="input-group-text" style="width: 40px"><span id="iconeDroit1"><i class="fa-solid fa-user-lock" style="color: #76D108"></i></span></div>
                                                                <select class="form-select" name="droit" id="droit1" onChange="iconeDroit(this)">
                                                                    <option value="visiteur" selected>Visiteur</option>
                                                                    <option value="admin">Admin</option>
                                                                    <option value="super admin">Super admin</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-12 col-md-4">
                                                            <label for="statu1"><strong>Statut</strong></label>
                                                        </div>
                                                        <div class="col-12 col-md-8">
                                                            <div class="input-group">
                                                                <div class="input-group-text" style="width: 40px"><span id="iconeStatut1"><i class="fa-solid fa-lock-open"></i></span></div>
                                                                <select class="form-select" name="desactive" id="statu1" onChange="iconeStatut(this)">
                                                                    <option value="non" selected>Activé</option>
                                                                    <option value="oui">Désactivé</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-12">
                                                    <br/>
                                                    <div class="text-end">
                                                        <input type="submit" class="btn btn-secondary" value="Créer" id="btnAc1" disabled/>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br/>';
                
                        if (isset($_SESSION["reinitialise"])) {
                            if ($_SESSION["reinitialise"] != null) {
                                echo '  <div class="text-center">
                                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                                <strong>Réinitialisé !</strong> Le mot de passe a été réinitialisé. Ce dernier est : <a class="text-decoration-none pointer" id="' . $_SESSION["reinitialise"] . '" onClick="copier(this)">' . $_SESSION["reinitialise"] . '</a>
                                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                            </div>
                                        </div>';
                                $_SESSION["reinitialise"] = null;
                            }
                        }
                        echo 
                        $cardComptes . '
                </div>
            </div>
            <script src="js/scriptGestionComptes.js?v=' . $numUnique . '"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
        </body>
        </html>';

        
        
    }
    else {
        header('Location: monCompte.php');
    }
?>
