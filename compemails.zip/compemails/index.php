
<?php
    require('traitement/verifConnecte.php');
    require('traitement/config.php');
    require('fonctionInterface.php');

    $numUnique = new DateTime();
    $numUnique = $numUnique->getTimestamp();

    $profil = '';
    $tableauComparatif = '';
    $tableauOrphelin = '';
    $modals = '';

    $nbCorrect = 0;
    $nbAdelManquant = 0;
    $nbEmailDiff = 0;
    $nbLIMaquant = 0;
    $nbLIMaquantAdelManquant = 0;
    $nbLIOrphelin = 0;

    $cheminCacheProfil = 'cache/profil.json';
    $cheminCacheStatut = 'cache/statut.json';

    $erreur = false;
    $hidden = '';
    $msgErreur = '';

    
    $notif =' hidden';
    $msgNotif = '';
    $entete = '';

    $btnTelechargerAdel = '';
    if ($droit == 'super admin' || $droit == 'admin') {
        $btnTelechargerAdel = '<a class="btn btn-info" href="" target="_blank"><i class="fa-solid fa-download"></i>&nbsp;CSV</a>';
        //Lien enlevé
    }

    $erreurImportante = false;
    if (isset($_SESSION['erreurImportante'])) {
        $erreurImportante = $_SESSION['erreurImportante'];
    }
    $chkBoxErreur = '';
    if ($erreurImportante) {
        $chkBoxErreur = ' checked';
    }

    $notif = ' hidden';
    if (isset($_SESSION["notif"]) && $_SESSION["notif"] != '') {
        if ($_SESSION["notif"] == "envoye") {
            $entete = '<strong class="me-auto"><i class="bi-globe"></i><i class="fa-solid fa-circle-check" style="color: green"></i></i> Envoyé</strong>';
            $msgNotif = 'Le mail a bien été envoyé.';
        }
        elseif ($_SESSION["notif"] == "refuse") {
            $entete = '<strong class="me-auto"><i class="bi-globe"></i><i class="fa-solid fa-circle-exclamation" style="color: red"></i> Refusé</strong>';
            $msgNotif = 'Vous n’avez pas les droits pour effectuer cette action.';
        }
        elseif ($_SESSION["notif"] == "erreurTransfert") {
            $entete = '<strong class="me-auto"><i class="bi-globe"></i><i class="fa-solid fa-circle-exclamation" style="color: red"></i> Erreur</strong>';
            $msgNotif = 'Une erreur est survenu lors du transfert.';
        }
        elseif ($_SESSION["notif"] == "formatIncorrect") {
            $entete = '<strong class="me-auto"><i class="bi-globe"></i><i class="fa-solid fa-circle-exclamation" style="color: red"></i> Erreur</strong>';
            $msgNotif = 'Le format du fichier est incorrect.';
        }
        elseif ($_SESSION["notif"] == "importe") {
            $entete = '<strong class="me-auto"><i class="bi-globe"></i><i class="fa-solid fa-circle-check" style="color: green"></i></i> Importé</strong>';
            $msgNotif = 'Le fichier a bien été importé.';
        }
        elseif ($_SESSION["notif"] == "modifie") {
            $entete = '<strong class="me-auto"><i class="bi-globe"></i><i class="fa-solid fa-circle-check" style="color: green"></i></i> Modifié</strong>';
            $msgNotif = 'Les modifications ont bien été apportées.';
        }
        elseif ($_SESSION["notif"] == "recharge") {
            $entete = '<strong class="me-auto"><i class="bi-globe"></i><i class="fa-solid fa-circle-check" style="color: green"></i></i> Recharge</strong>';
            $msgNotif = 'La BDD LI a bien été rechargé.';
        }
        $notif = '';
        $_SESSION["notif"] = '';
    }

    $mailPre = requeteRecupererMailPre();
    $mailPreDiff = array($mailPre[0]['numMailPre'], $mailPre[0]['campagne'], $mailPre[0]['objet'], $mailPre[0]['message']);
    $mailPreAdel = array($mailPre[1]['numMailPre'], $mailPre[1]['campagne'], $mailPre[1]['objet'], $mailPre[1]['message']);

    // -====================> Vérifier si le cache existe <====================-

    
    fichierCache();
    $statut = file_get_contents($cheminCacheStatut);
    $profil = file_get_contents($cheminCacheProfil);
    if ($profil != '') {
        
    }
    else {
        if (isset($_SESSION['valeurLI']) == false || isset($_SESSION['valeurAdel']) == false || $_SESSION['valeurLI'] == null || $_SESSION['valeurAdel'] == null) {
            $erreur = traitement(listeFichier('LI', 4), listeFichier('Adel', 4)); //Traitement automatique si les fichiers caches ont été surpprimé
        }
        else {
            $erreur = traitement(listeFichier("LI", $_SESSION['valeurLI']), listeFichier("Adel", $_SESSION['valeurAdel'])); //Traitement en appuyant sur le bouton Calculer
            $_SESSION['valeurLI'] = null;
            $_SESSION['valeurAdel'] = null;
        }
        $profil = file_get_contents($cheminCacheProfil);
    }
    if ($statut != '') {
        
    }
    else {
        $statut = file_get_contents($cheminCacheStatut);
    }

    $statut = json_decode($statut);
    $profil = json_decode($profil, true);
    
    $selectLI = ajouterSelectLI();
    $selectAdel = ajouterSelectAdel();
    $dateFichierLI = 'Aucune date disponible';
    if ($profil != '' && $profil[1][1] != '' && $profil[1][1] != null && $profil[1][1] != 'null' && $profil[1][1] != 'NULL') {
        $dateFichierLI = date("d/m/Y à H\hi", $profil[1][1]);
    }
    $dateFichierAdel = 'Aucune date disponible';
    if ($profil != '' && $profil[1][3] != '' && $profil[1][3] != null && $profil[1][3] != 'null' && $profil[1][3] != 'NULL') {
        $dateFichierAdel = date("d/m/Y à H\hi", $profil[1][3]);
    }

    if ($erreur) {  
        $hidden = 'hidden';
        $msgErreur = '  <div class="text-center red">
                            <strong>
                                <br/><br/>
                                Une erreur est survenue lors du calcul.<br/>
                                Cela est probablement dû à des fichiers cache de BDD introuvablent.
                            </strong>
                        </div>';
    }

    




    // -====================> Récupération du cache et création des tableaux + statistiques <====================-

    $historique = requeteRecupererHistorique();
    $exception = requeteRecupererException();
    $i = 0;
    if (is_array($profil)) {
        foreach ($profil[0] as $uneLigne) {
            $idModalMail = 'modalMail' . $i;
            $idModalSuivi = 'modalSuivi' . $i;
            
            $ligneMailAdelBureau = '';
            if ($uneLigne[4] == '') {
                $ligneMailAdelBureau = '<td><div class="text-center"><i class="fa-solid fa-xmark"></i></div></td>';
            }
            elseif ($uneLigne[3] != $uneLigne[4]) {
                $ligneMailAdelBureau = '<td><div data-bs-toggle="tooltip" title="Copier dans le presse-papier"><i class="fa-solid fa-circle-xmark" style="color:red">&nbsp;</i><a class="text-decoration-none pointer" id="' . $uneLigne[4] . '" onClick="copier(this)">' . $uneLigne[4] . '</a></div></td>';
            }
            else {
                $ligneMailAdelBureau = '<td><div data-bs-toggle="tooltip" title="Copier dans le presse-papier"><i class="fa-solid fa-circle-check" style="color:green"></i>&nbsp;<a class="text-decoration-none pointer" id="' . $uneLigne[4] . '" onClick="copier(this)">' . $uneLigne[4] . '</a></div></td>';
            }

            if ($uneLigne[6] == 1) { //Code erreur : 1 (Profil correct)
                if ($erreurImportante == false) {
                    $suivi = recupHistorique($uneLigne[0], $historique);
                    $iconeSuivi = '';
                    if ($suivi != null) {
                        $iconeSuivi = '<div data-bs-toggle="tooltip" title="Historique des mails envoyés" class="text-center"><i class="fa-solid fa-circle-info fa-2xl pointer" data-bs-toggle="modal" data-bs-target="#' . $idModalSuivi . '"></i></div>';
                        $modals .= ajouterModalSuivi($idModalSuivi, $uneLigne[0], $historique, $suivi, $uneLigne[1], $uneLigne[2], $i);
                    }
                    $tableauComparatif .= ' <tr class="table-secondary">
                                                <td><strong>' . $uneLigne[0] . '</strong></td>
                                                <td>' . $uneLigne[1] . '</td>
                                                <td>' . $uneLigne[2] . '</td>
                                                <td><div data-bs-toggle="tooltip" title="Copier dans le presse-papier"><a class="text-decoration-none pointer" id="' . $uneLigne[3] . '" onClick="copier(this)">' . $uneLigne[3] . '</a></div></td>
                                                ' . $ligneMailAdelBureau . '
                                                <td><div data-bs-toggle="tooltip" title="Copier dans le presse-papier"><a class="text-decoration-none pointer" id="' . $uneLigne[5] . '" onClick="copier(this)">' . $uneLigne[5] . '</a></div></td>
                                                <td><div class="text-center"><i class="fa-solid fa-xmark"></i></div></td>
                                                <td>' . $iconeSuivi . '</td>
                                                <td>' . ajouterStatut($statut, $uneLigne[5]) . '</td>
                                            </tr>';
                    $nbCorrect++;
                }
            }
            elseif ($uneLigne[6] == 2) { //Code erreur : 2 (Mails différents)
                $tableauComparatif .= ' <tr class="table-warning">
                                            <td><strong>' . $uneLigne[0] . '</strong></td>
                                            <td>' . $uneLigne[1] . '</td>
                                            <td>' . $uneLigne[2] . '</td>
                                            <td><div data-bs-toggle="tooltip" title="Copier dans le presse-papier"><a class="text-decoration-none pointer" id="' . $uneLigne[3] . '" onClick="copier(this)">' . $uneLigne[3] . '</a></div></td>
                                            ' . $ligneMailAdelBureau . '
                                            <td><div data-bs-toggle="tooltip" title="Copier dans le presse-papier"><a class="text-decoration-none pointer" id="' . $uneLigne[5] . '" onClick="copier(this)">' . $uneLigne[5] . '</a></div></td>
                                            <td>Mails différents</td>
                                            <td><div data-bs-toggle="tooltip" title="Envoyer un mail" class="text-center"><i class="fa-solid fa-envelope fa-2xl pointer" data-bs-toggle="modal" data-bs-target="#' . $idModalMail . '"></i></div></td>
                                            <td>' . ajouterStatut($statut, $uneLigne[5]) . '</td>
                                        </tr>';
                $modals .= ajouterModalMail($idModalMail, $uneLigne[1], $uneLigne[2], $uneLigne[5], $uneLigne[3], $uneLigne[0], $historique, $mailPre, $i);
                $nbEmailDiff++;
            }
            elseif ($uneLigne[6] == 3) { //Code erreur : 3 (Adel manquant)
                $tableauComparatif .= ' <tr class="table-danger">
                                            <td><strong>' . $uneLigne[0] . '</strong></td>
                                            <td>' . $uneLigne[1] . '</td>
                                            <td>' . $uneLigne[2] . '</td>
                                            <td><div class="text-center"><i class="fa-solid fa-xmark"></i></div></td>
                                            ' . $ligneMailAdelBureau . '
                                            <td><div data-bs-toggle="tooltip" title="Copier dans le presse-papier"><a class="text-decoration-none pointer" id="' . $uneLigne[5] . '" onClick="copier(this)">' . $uneLigne[5] . '</a></div></td>
                                            <td>Adel manquant (mail)</td>
                                            <td><div data-bs-toggle="tooltip" title="Envoyer un mail" class="text-center"><i class="fa-solid fa-envelope fa-2xl pointer" data-bs-toggle="modal" data-bs-target="#' . $idModalMail . '"></i></div></td>
                                            <td>' . ajouterStatut($statut, $uneLigne[5]) . '</td>
                                        </tr>';
                $modals .= ajouterModalMail($idModalMail, $uneLigne[1], $uneLigne[2],  $uneLigne[5], null, $uneLigne[0], $historique, $mailPre, $i);
                $nbAdelManquant++;
            }
            elseif ($uneLigne[6] == 4) { //Code erreur : 4 (LI manquant)
                if ($erreurImportante == false) {
                    $suivi = recupHistorique($uneLigne[0], $historique);
                    $iconeSuivi = '';
                    if ($suivi != null) {
                        $iconeSuivi = '<div data-bs-toggle="tooltip" title="Historique des mails envoyés" class="text-center"><i class="fa-solid fa-circle-info fa-2xl pointer" data-bs-toggle="modal" data-bs-target="#' . $idModalSuivi . '"></i></div>';
                        $modals .= ajouterModalSuivi($idModalSuivi, $uneLigne[0], $historique, $suivi, $uneLigne[1], $uneLigne[2], $i);
                    }
                    $tableauComparatif .= ' <tr class="table-secondary">
                                                <td><strong>' . $uneLigne[0] . '</strong></td>
                                                <td>' . $uneLigne[1] . '</td>
                                                <td>' . $uneLigne[2] . '</td>
                                                <td><div data-bs-toggle="tooltip" title="Copier dans le presse-papier"><a class="text-decoration-none pointer" id="' . $uneLigne[3] . '" onClick="copier(this)">' . $uneLigne[3] . '</a></div></td>
                                                ' . $ligneMailAdelBureau . ' 
                                                <td><div class="text-center"><i class="fa-solid fa-xmark"></i></div></td>
                                                <td>LI manquant (profil)</td>
                                                <td>' . $iconeSuivi . '</td>
                                                <td>' . ajouterStatut($statut, $uneLigne[5]) . '</td>
                                            </tr>';
                    $nbLIMaquant++;
                }
            }
            elseif ($uneLigne[6] == 5) { //Code erreur : 5 (LI manquant et Adel manquant)
                if ($erreurImportante == false) {
                    $suivi = recupHistorique($uneLigne[0], $historique);
                    $iconeSuivi = '';
                    if ($suivi != null) {
                        $iconeSuivi = '<div data-bs-toggle="tooltip" title="Historique des mails envoyés" class="text-center"><i class="fa-solid fa-circle-info fa-2xl pointer" data-bs-toggle="modal" data-bs-target="#' . $idModalSuivi . '"></i></div>';
                        $modals .= ajouterModalSuivi($idModalSuivi, $uneLigne[0], $historique, $suivi, $uneLigne[1], $uneLigne[2], $i);
                    }
                    $tableauComparatif .= ' <tr class="table-secondary">
                                                <td><strong>' . $uneLigne[0] . '</strong></td>
                                                <td>' . $uneLigne[1] . '</td>
                                                <td>' . $uneLigne[2] . '</td>
                                                <td><div class="text-center"><i class="fa-solid fa-xmark"></i></div></td>
                                                ' . $ligneMailAdelBureau . '
                                                <td><div class="text-center"><i class="fa-solid fa-xmark"></i></div></td>
                                                <td>LI manquant (profil) & Adel manquant (mail)</td>
                                                <td>' . $iconeSuivi . '</td>
                                                <td>' . ajouterStatut($statut, $uneLigne[5]) . '</td>
                                            </tr>';
                    $nbLIMaquantAdelManquant++;
                }
            }
            elseif ($uneLigne[6] == 6) { //Code erreur : 6 (LI orphelin)
                $visibleCache = verifierException($uneLigne[0], $exception);
                $ligneOeil = '';
                $ligneTR = '<tr class="table-warning">';
                if ($visibleCache == 'visible') {
                    $ligneOeil = '<div data-bs-toggle="tooltip" title="Mettre en exception" class="text-center"><a href="traitement/traitementException.php?action=ajout&idLI=' . $uneLigne[0] . '"><i class="fa-solid fa-eye fa-2xl" style="color: black;"></i></a></div>';
                    $ligneTR = '<tr class="table-warning">';
                    $nbLIOrphelin++;
                }
                elseif ($visibleCache == 'cache') {
                    $ligneOeil = '<div data-bs-toggle="tooltip" title="Supprimer l’exception" class="text-center"><a href="traitement/traitementException.php?action=supp&idLI=' . $uneLigne[0] . '"><i class="fa-solid fa-eye-slash fa-2xl" style="color: #6b6b6b;"></i></a></div>';
                    $ligneTR = '<tr class="table-secondary">';
                }
                $tableauOrphelin .=  $ligneTR . '
                                            <td><strong>' . $uneLigne[0] . '</strong></td>
                                            <td>' . $uneLigne[1] . '</td>
                                            <td>' . $uneLigne[2] . '</td>
                                            <td><div data-bs-toggle="tooltip" title="Copier dans le presse-papier"><a class="text-decoration-none pointer" id="' . $uneLigne[5] . '" onClick="copier(this)">' . $uneLigne[5] . '</a></div></td>
                                            <td>' . $ligneOeil . '</td>
                                        </tr>';
            }
            $i++;
        }
    }


    

    // -====================> Statistiques <====================-
    $sommeProfil = $nbCorrect + $nbEmailDiff + $nbAdelManquant + $nbLIMaquant + $nbLIMaquantAdelManquant + $nbLIOrphelin;
    $pourcentCorrect = 0;
    $pourcentDiff = 0;
    $pourcentAdelManquant = 0;
    $pourcentLIManquant = 0;
    $pourcentLIManquantAdelManquant = 0;
    $pourcentLIOrphelin = 0;

    $hiddenCorrect = '';
    $hiddenDiff = '';
    $hiddenAdelManquant = '';
    $hiddenLIManquant = '';
    $hiddenLIManquantAdelManquant = '';
    $hiddenLIOrphelin = '';

    if ($nbCorrect == 0) {
        $hiddenCorrect = ' hidden';
    }
    if ($nbEmailDiff == 0) {
        $hiddenDiff = ' hidden';
    }
    if ($nbAdelManquant == 0) {
        $hiddenAdelManquant = ' hidden';
    }
    if ($nbLIMaquant == 0) {
        $hiddenLIManquant = ' hidden';
    }
    if ($nbLIMaquantAdelManquant == 0) {
        $hiddenLIManquantAdelManquant = ' hidden';
    }
    if ($nbLIOrphelin == 0) {
        $hiddenLIOrphelin = ' hidden';
    }
    
    if ($sommeProfil != 0) {
        $pourcentCorrect = (int) ($nbCorrect / $sommeProfil * 100);
        $pourcentDiff = (int) ($nbEmailDiff / $sommeProfil * 100);
        $pourcentAdelManquant = (int) ($nbAdelManquant / $sommeProfil * 100);
        $pourcentLIManquant = (int) ($nbLIMaquant / $sommeProfil * 100);
        $pourcentLIManquantAdelManquant = (int) ($nbLIMaquantAdelManquant / $sommeProfil * 100);
        $pourcentLIOrphelin = (int) ($nbLIOrphelin / $sommeProfil * 100);
    }
    
    // -========================================================-
    

    
    echo '
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8" />
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href="css/bootstrapPerso.css?v=' . $numUnique . '" />
        <meta name="viewport" content="width=device-width, initial-scale=1">    
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <title>Comparatif</title>
        <link rel="icon" type="image/png" sizes="250x250" href="image/bddIcone.png?v=' . $numUnique . '">
    </head>
    <body>
        <nav class="navbar fixed-top navbar-expand-lg bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">Accueil</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="#titreOrphelin">Profils orphelins</a>
                        </li>
                    </ul>
                    <div class="navbar-collapse justify-content-end" id="navbarCollapse">
                            <ul class="navbar-nav">
                                <li class="nav-item dropdown">
                                    <a class="btn btn-sm btn-outline-secondary text-start changeButton" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fa-solid fa-gear"></i><span class="d-block d-lg-none ligne">&nbsp;Paramètres</span></a>
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                        <li><a class="dropdown-item" data-bs-toggle="modal" data-bs-target="#parametreBDD" style="cursor: pointer"><i class="fa-solid fa-database"></i>&nbsp;BDD</a></li>
                                        <li><a class="dropdown-item" data-bs-toggle="modal" data-bs-target="#parametreMails" style="cursor: pointer"><i class="fa-solid fa-envelope"></i>&nbsp;Mails</a></li>
                                        <li><a class="dropdown-item" data-bs-toggle="modal" data-bs-target="#modalDoc" style="cursor: pointer"><i class="fa-solid fa-book"></i>&nbsp;Documentation</a></li>
                                    </ul>
                                </li>
                                <li class="nav-item">
                                    <a class="btn btn-sm btn-outline-secondary text-start changeButton" type="button" href="monCompte.php"><i class="fa-solid fa-user"></i>&nbsp;' . $mail . '</a>
                                </li>
                                <li class="nav-item">
                                    <a class="btn btn-sm btn-outline-secondary text-start changeButton" type="button" href="traitement/traitementDeconnexion.php"><i class="fa-solid fa-arrow-right-from-bracket"></i><span class="d-block d-lg-none ligne">&nbsp;Déconnexion</span></a>
                                </li>
                            </ul>
                        </div>
                </div>
            </div>
        </nav>
        <br/><br/><br/>
        <div class="container-fluid">
            <div class="text-center">
                <div class="row">
                    <div class="col-xxl-1 col-md-4">
                        <div class="card">
                            <div class="card-body"> 
                                <h4 class="card-title" id="titre">Profils total</h4>
                                <h1>' . $sommeProfil . '</h1>
                                <div class="progress">
                                    <div class="progress-bar bg-success" role="progressbar" style="width: 100%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">100 %</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xxl-2 col-md-4">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Profils corrects</h4><br/>
                                <h1>' . $nbCorrect . '<a href="traitement/telechargementCSV.php?typeExport=tabProfilCorrect" class="text-decoration-none"' . $hiddenCorrect . '><span data-bs-toggle="tooltip" title="Exporter au format CSV">&nbsp;<i class="fa-solid fa-file-arrow-down fa-xs" style="color:black"></i></span></a></h1>
                                <div class="progress">
                                    <div class="progress-bar bg-info" role="progressbar" style="width: ' . $pourcentCorrect . '%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">' . $pourcentCorrect . ' %</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xxl-2 col-md-4">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Profils mails différents</h4><br/>
                                <h1>' . $nbEmailDiff . '<a href="traitement/telechargementCSV.php?typeExport=tabMailDiff" class="text-decoration-none"' . $hiddenDiff . '><span data-bs-toggle="tooltip" title="Exporter au format CSV">&nbsp;<i class="fa-solid fa-file-arrow-down fa-xs" style="color:black"></i></span></a></h1>
                                <div class="progress">
                                    <div class="progress-bar bg-info" role="progressbar" style="width: ' . $pourcentDiff . '%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">' . $pourcentDiff . ' %</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xxl-2 col-md-3">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Profils Adel manquant (mail)</h4>
                                <h1>' . $nbAdelManquant . '<a href="traitement/telechargementCSV.php?typeExport=tabAdelManquant" class="text-decoration-none"' . $hiddenAdelManquant . '><span data-bs-toggle="tooltip" title="Exporter au format CSV">&nbsp;<i class="fa-solid fa-file-arrow-down fa-xs" style="color:black"></i></span></a></h1>
                                <div class="progress">
                                    <div class="progress-bar bg-info" role="progressbar" style="width: ' . $pourcentAdelManquant . '%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">' . $pourcentAdelManquant . ' %</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xxl-2 col-md-3">
                        <div class="card">
                            <div class="card-body"> 
                                <h4 class="card-title">Profils LI manquants (profils)</h4>
                                <h1>' . $nbLIMaquant . '<a href="traitement/telechargementCSV.php?typeExport=tabLIManquant" class="text-decoration-none"' . $hiddenLIManquant . '><span data-bs-toggle="tooltip" title="Exporter au format CSV">&nbsp;<i class="fa-solid fa-file-arrow-down fa-xs" style="color:black"></i></span></a></h1>
                                <div class="progress">
                                    <div class="progress-bar bg-info" role="progressbar" style="width: ' . $pourcentLIManquant . '%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">' . $pourcentLIManquant . ' %</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xxl-2 col-md-3">
                        <div class="card">
                            <div class="card-body"> 
                                <h4 class="card-title">Profils LI manquant et Adel manquant</h4>
                                <h1>' . $nbLIMaquantAdelManquant . '<a href="traitement/telechargementCSV.php?typeExport=tabLIManquantAdelManquant" class="text-decoration-none"' . $hiddenLIManquantAdelManquant . '><span data-bs-toggle="tooltip" title="Exporter au format CSV">&nbsp;<i class="fa-solid fa-file-arrow-down fa-xs" style="color:black"></i></span></a></h1>
                                <div class="progress">
                                    <div class="progress-bar bg-info" role="progressbar" style="width: ' . $pourcentLIManquantAdelManquant . '%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">' . $pourcentLIManquantAdelManquant . ' %</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xxl-1 col-md-3">
                        <div class="card">
                            <div class="card-body"> 
                                <h4 class="card-title"><a class="text-decoration-none pointer black" href="#titreOrphelin">Profils orphelins</a></h4>
                                <h1> ' . $nbLIOrphelin . '<a href="traitement/telechargementCSV.php?typeExport=tabProfilOrphelin" class="text-decoration-none"' . $hiddenLIOrphelin . '><span data-bs-toggle="tooltip" title="Exporter au format CSV">&nbsp;<i class="fa-solid fa-file-arrow-down fa-xs" style="color:black"></i></span></a></h1>
                                <div class="progress">
                                    <div class="progress-bar bg-info" role="progressbar" style="width: ' . $pourcentLIOrphelin . '%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">' . $pourcentLIOrphelin . ' %</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <br/>
            <div class="row">
                <div class="col-12" ' . $hidden . '>
                    <div class="toast-container" style="position: absolute; top: 60px; left: 10px;">
                        <div class="toast fade show bg-white" id="notif"' . $notif . '>
                            <div class="toast-header">
                                ' . $entete . '
                            </div>
                            <div class="toast-body">
                            ' . $msgNotif . '
                            </div>
                        </div>
                    </div>
                    <h1 id="titreComparatif" class="text-center">Comparatif Adel / LI</h1><br/>
                    <div class="table-responsive">
                        <table id="tableComparatif" class="table align-middle" >
                            <thead>
                                <tr class="table-dark">
                                    <th>ID Adel</th>
                                    <th>Prénom</th>
                                    <th>Nom</th>
                                    <th>Email Adel (Principale)</th>
                                    <th>Email Adel (Bureau)</th>
                                    <th>Email LI</th>
                                    <th>Erreur</th>
                                    <th>Action</th>
                                    <th>Statut</th>
                                </tr>
                            </thead>
                            <tbody>
                                ' . $tableauComparatif . '
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-12" ' . $hidden . '>
                    <h1 id="titreOrphelin" class="text-center">Orphelins LI</h1><br/>
                    <div class="table-responsive">
                        <table id="tableOrphelin" class="table align-middle">
                            <thead>
                                <tr class="table-dark">
                                    <th>ID LI</th>
                                    <th>Prénom</th>
                                    <th>Nom</th>
                                    <th>Email</th>
                                    <th>Exception</th>
                                </tr>
                            </thead>
                            <tbody>
                                ' . $tableauOrphelin. '
                            </tbody>
                        </table>
                    </div>
                </div>
                ' . $msgErreur . '
                <div class="modal fade bd-example-modal-lg" id="parametreBDD" tabindex="-1" aria-labelledby="modalParaBDD" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="modalParaBDD">Paramètres BDD</h5>
                                <div id="elementChargementPara" hidden>
                                    <div class="d-flex justify-content-center">
                                        &nbsp;&nbsp;
                                        <div class="spinner-border" role="status"></div>
                                        &nbsp;En cours
                                    </div>
                                </div>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-12 col-lg-4">
                                        <div class="card">
                                            <div class="card-body">
                                                <h5 class="card-title">BDD LI</h5>
                                                <p class="card-text">Date du fichier utlisé :<br/><i>' . $dateFichierLI . '</i></p>
                                                <a href="traitement/rechargerLI.php?forcer=on" class="btn btn-secondary"><i class="fa-solid fa-arrows-rotate"></i>&nbsp;Recharger</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-lg-4">
                                        <div class="card">
                                            <div class="card-body">
                                                <h5 class="card-title">BDD Adel</h5>
                                                <p class="card-text">Date du fichier utlisé :<br/><i>' . $dateFichierAdel . '</i></p>
                                                <form action="traitement/traitementImport.php" method="POST" enctype="multipart/form-data">
                                                    <input class="form-control" type="file" id="fichier" name="fichier" accept=".csv" required>
                                                    <br/>
                                                    <br/>
                                                    <div class="btn-group" role="group" aria-label="Basic example">
                                                        ' . $btnTelechargerAdel . '
                                                        <input type="submit" class="btn btn-secondary" value="Importer"/>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-lg-4">
                                        <div class="card">
                                            <div class="card-body">
                                                <form action="traitement/traitementActualiser.php" method="GET">
                                                    <h5 class="card-title">Calculer</h5>
                                                    <p class="card-text">
                                                        <label for="valeurLI" class="form-label">Date LI</label>
                                                        ' . $selectLI . '
                                                        <label for="valeurAdel" class="form-label">Date Adel</label>
                                                        ' . $selectAdel . '
                                                        <br/>
                                                        <input type="submit" class="btn btn-secondary" id="btnRecalculer" name="submit" value="Calculer">
                                                    </p>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <br/>
                                <form action="traitement/traitementParametre.php" method="GET">
                                    <input type="checkbox" id="erreurImportante" name="erreurImportante"' . $chkBoxErreur . '><label for="erreurImportante">&nbsp;Afficher uniquement les importantes erreurs</label><br/><br/>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal fade bd-example-modal-lg" id="parametreMails" tabindex="-1" aria-labelledby="modalParaMail" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <form action="traitement/traitementMailPre.php" method="POST">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="modalParaMail">Paramètres mails prédéfinis</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="row">
                                        <div class="col-12 col-sm-6">
                                            <h2 class="text-center">Mails différents</h2>
                                            <input type="hidden" class="form-control" name="numMailPreDiff" id="numMailPreDiff" value="' . $mailPreDiff[0] . '" required>
                                            <div class="form-group">
                                                <label for="campagneDiff"><strong>Campagne MailJet</strong></label>
                                                <input type="text" class="form-control" name="campagneDiff" id="campagneDiff" value="' . $mailPreDiff[1] . '" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="objetDiff"><strong>Objet</strong></label>
                                                <input type="text" class="form-control" name="objetDiff" id="objetDiff" value="' . $mailPreDiff[2] . '" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="contenuMailDiff"><strong>Contenu du mail</strong></label>
                                                <textarea class="form-control" name="contenuMailDiff" id="contenuMailDiff" rows="18" required>' . $mailPreDiff[3] . '</textarea>
                                            </div>
                                        </div>
                                        <div class="col-12 col-sm-6">
                                            <h2 class="text-center">Adel manquant</h2>
                                            <input type="hidden" class="form-control" name="numMailPreAdel" id="numMailPreAdel" value="' . $mailPreAdel[0] . '" required>
                                            <div class="form-group">
                                                <label for="campagneAdel"><strong>Campagne MailJet</strong></label>
                                                <input type="text" class="form-control" name="campagneAdel" id="campagneAdel" value="' . $mailPreAdel[1] . '" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="objetAdel"><strong>Objet</strong></label>
                                                <input type="text" class="form-control" name="objetAdel" id="objetAdel" value="' . $mailPreAdel[2] . '" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="contenuMailAdel"><strong>Contenu du mail</strong></label>
                                                <textarea class="form-control" name="contenuMailAdel" id="contenuMailAdel" rows="18" required>' . $mailPreAdel[3] . '</textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-12" style="color: grey">
                                            <a class="text-decoration-none pointer" id="mailLICopier" onClick="copier(this)">[[mailLI]]</a> = Mail lettre interne<br/>
                                            <a class="text-decoration-none pointer" id="mailAdelCopier" onClick="copier(this)">[[mailAdel]]</a> = Mail Adel
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <div class="form-group">
                                        <input type="submit" class="btn btn-secondary" value="Enregistrer">
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="modal fade bd-example-modal-lg" id="modalDoc" tabindex="-1" aria-labelledby="modalDoc" aria-hidden="true">
                    <div class="modal-dialog modal-xl">
                        <div class="modal-content bg-grey">
                            <div class="modal-header">
                                <h5 class="modal-title" id="modalDoc">Documentation</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <h2 id="titreActuaLI">Actualiser BDD lettre interne</h2>
                                <br/>
                                <div class="row">
                                    <div class="col-lg-4 col-12">
                                        La base de données lettre interne s’actualise automatiquement tous les jours à 5 h 00 du matin. Pour forcer son actualisation, il vous suffit de cliquer sur le bouton entouré en rouge ci-contre. Un message de confirmation sera affiché une fois le chargement effectué.
                                    </div>
                                    <div class="col-lg-8 col-12">
                                        <img src="image/actualiserLIimg1.png" class="img-fluid">
                                    </div>
                                </div>

                                <br/><br/><br/><br/>
                                <h2 id="titreActuaAdel">Actualiser BDD Adel</h2>
                                <br/>
                                <div class="row">
                                    <div class="col-lg-8 col-12">
                                        L’actualisation de la base de données Adel n’est pas automatique. Vous devez alors appuyer sur le bouton bleu. Celui-ci ouvrira un nouvel onglet, rentrez les informations pour télécharger la BDD sur votre ordinateur.
                                    </div>
                                    <div class="col-lg-4 col-12">
                                        <img src="image/actualiserAdelimg1.png" class="img-fluid">
                                    </div>
                                </div>
                                <br/>
                                <div class="row">
                                    <div class="col-lg-4 col-12">
                                        Une fois cela fait, vous devez importer le fichier en appuyant sur « Parcourir » et en séléctionnant le fichier. Après cela, cliquez sur « Importer », un message de confirmation apparaîtra.
                                    </div>
                                    <div class="col-lg-8 col-12">
                                        <img src="image/actualiserAdelimg2.png" class="img-fluid">
                                    </div>
                                </div>

                                <br/><br/><br/><br/>
                                <h2 id="titreActuaStatut">Actualiser le statut des mails</h2>
                                <br/>
                                <div class="row">
                                    <div class="col-lg-4 col-12">
                                        Les statuts des mails s’actualisent automatiquement tous les jours à 5 h 00 du matin. Pour forcer son actualisation, il faut appuyer sur le bouton « Calculer ». Cette opération peut prendre quelques secondes.
                                    </div>
                                    <div class="col-lg-8 col-12">
                                        <img src="image/actualiserStatutimg1.png" class="img-fluid">
                                    </div>
                                </div>

                                <br/><br/><br/><br/>
                                <h2 id="titreLancerCalcul">Lancer le calcul des erreurs</h2>
                                <br/>
                                <div class="row">
                                    <div class="col-lg-4 col-12">
                                        Le calcul des erreurs se réalise automatiquement tous les jours à 5 h 00 du matin. Pour forcer le calcul, il faut appuyer sur le bouton « Calculer » en ayant séléctionné la date des fichiers BDD souhaitée. Attention, ce sont uniquement les 4 fichiers les plus récents qui sont conservés. Cette opération peut prendre quelques secondes.
                                    </div>
                                    <div class="col-lg-8 col-12">
                                        <img src="image/calculerimg1.png" class="img-fluid">
                                    </div>
                                </div>
                                <br/>
                                <div class="row">
                                    <div class="col-lg-4 col-12">
                                        La date du fichier utilisé pour chaque import de BDD est affichée.
                                    </div>
                                    <div class="col-lg-8 col-12">
                                        <img src="image/calculerimg2.png" class="img-fluid">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                
                ' . $modals . '
            </div>
        </div>
        <script src="js/scriptIndex.js?v=' . $numUnique . '"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    </body>
    </html>';
?>


