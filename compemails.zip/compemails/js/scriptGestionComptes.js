let titre = document.getElementById("titre");
let notif = document.getElementById("notif");
let txtMd1 = document.getElementById("txtMd1");
let btnRe1 = document.getElementById("btnRe1");

window.addEventListener("load", verifierNotif);
window.addEventListener("load", genererMdp);
btnRe1.addEventListener("click", genererMdp);

function copier(element) {
    let text = document.getElementById(element.id);
    let textToCopy = document.createElement('input');
    textToCopy.type = "text";
    textToCopy.value = text.textContent;
    titre.appendChild(textToCopy);
    textToCopy.select();
    document.execCommand("Copy");
    titre.removeChild(textToCopy);
}

function copierMdp() {
    txtMd1.select();
    document.execCommand("Copy");
    titre.removeChild(textToCopy);
}

function verifierNotif() {
    if (notif.hidden == false) {
        setTimeout(cacherAlert, 5000);
    }
}

function cacherAlert() {
    notif.hidden = true;
}

function iconeDroit(element) {
    let select = document.getElementById(element.id);
    let div = document.getElementById("iconeDroit" + element.id.substring(5));
    if (select.value == 'super admin') {
        div.innerHTML = '<i class="fa-solid fa-crown" style="color: #FACD03"></i>';
    }
    else if (select.value == 'admin') {
        div.innerHTML = '<i class="fa-solid fa-user-tie" style="color: #F11212"></i>';
    }
    else if (select.value == 'visiteur') {
        div.innerHTML = '<i class="fa-solid fa-user-lock" style="color: #76D108"></i>';
    }
    modifRealise(element);
}

function iconeStatut(element) {
    let select = document.getElementById(element.id);
    let div = document.getElementById("iconeStatut" + element.id.substring(5));
    if (select.value == 'non') {
        div.innerHTML = '<i class="fa-solid fa-lock-open" ></i>';
    }
    else if (select.value == 'oui') {
        div.innerHTML = '<i class="fa-solid fa-lock"></i>';
    }
    modifRealise(element);
}

function modifRealise(element) {
    let txtNo = document.getElementById("txtNo" + element.id.substring(5));
    let txtPr = document.getElementById("txtPr" + element.id.substring(5));
    let txtMa = document.getElementById("txtMa" + element.id.substring(5));
    let txtMd = document.getElementById("txtMd" + element.id.substring(5));
    let btnAc = document.getElementById("btnAc" + element.id.substring(5));
    if (document.getElementById("txtMd" + element.id.substring(5))) {
        if (txtNo.value.length == 0 || txtPr.value.length == 0 || txtMa.value.length == 0 || txtMd.value.length < 8) {
            btnAc.disabled = true;
        }
        else {
            btnAc.disabled = false;
        }
    }
    else {
        if (txtNo.value.length == 0 || txtPr.value.length == 0 || txtMa.value.length == 0) {
            btnAc.disabled = true;
        }
        else {
            btnAc.disabled = false;
        }
    }
}

function genererMdp() {
    let mdp = '';
    let alphabet = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V','W', 'X', 'Y', 'Z'];
    for (let i = 0 ; i < 8 ; i++) {
        let choix = Math.floor(Math.random() * 3);
        if (choix == 0 || choix == 1) {
            let maj = Math.floor(Math.random() * 2);
            let lettre = Math.floor(Math.random() * alphabet.length)
            if (maj == 0) {
                mdp += alphabet[lettre].toLowerCase();
            }
            else {
                mdp += alphabet[lettre].toUpperCase();
            }
        }
        else {
            mdp += Math.floor(Math.random() * 10);
        }
    }
    txtMd1.value = mdp;
}
