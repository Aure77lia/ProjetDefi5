let titre = document.getElementById("titre");
let titreModalParaMail = document.getElementById("modalParaMail");
let btnRecalculer = document.getElementById("btnRecalculer");
let erreurImportante = document.getElementById("erreurImportante");
let elementChargementNav = document.getElementById("elementChargementNav");
let elementChargementPara = document.getElementById("elementChargementPara");
let notif = document.getElementById("notif");

btnRecalculer.addEventListener("click", chargementPara);
erreurImportante.addEventListener("click", traitementParametre);
window.addEventListener("load", verifierNotif);


function chargementPara() {
    elementChargementPara.hidden = false;
}

function copier(element) {
    let text = document.getElementById(element.id);
    let textToCopy = document.createElement('input');
    textToCopy.type = "text";
    textToCopy.value = text.textContent;
    if (element.id == 'mailLICopier' || element.id == 'mailAdelCopier') {
        titreModalParaMail.appendChild(textToCopy);
    }
    else {
        titre.appendChild(textToCopy);
    }
    textToCopy.select();
    document.execCommand("Copy");
    if (element.id == 'mailLICopier' || element.id == 'mailAdelCopier') {
        titreModalParaMail.removeChild(textToCopy);
    }
    else {
        titre.removeChild(textToCopy);
    }
}

function verifierNotif() {
    if (notif.hidden == false) {
        setTimeout(cacherNotif, 5000);
    }
}

function cacherNotif() {
    notif.hidden = true;
}


function traitementParametre() {
    if (erreurImportante.checked) {
        window.location.href = "traitement/traitementParametre.php?erreurImportante=on&submit=Appliquer";
    }
    else {
        window.location.href = "traitement/traitementParametre.php?submit=Appliquer";
    }
}