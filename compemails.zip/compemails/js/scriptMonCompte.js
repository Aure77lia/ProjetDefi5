let modifierMdp = document.getElementById("modifierMdp");
let btnModifier = document.getElementById("btnModifier");
let notif = document.getElementById("notif");
let mdpAncien = document.getElementById("mdpAncien");
let mdp1 = document.getElementById("mdp1");
let mdp2 = document.getElementById("mdp2");
let btnChanger = document.getElementById("btnChanger");
let cacher = false;

btnModifier.addEventListener("click", afficher);
mdpAncien.addEventListener("keyup", verifMdp);
mdp1.addEventListener("keyup", verifMdp);
mdp2.addEventListener("keyup", verifMdp);
window.addEventListener("load", verifierNotif);


function afficher() {
    if (cacher == false) {
        cacher = true;
        modifierMdp.hidden = false;
        btnModifier.textContent= "Ne pas modifier";
    }
    else {
        cacher = false;
        modifierMdp.hidden = true;
        btnModifier.textContent= "Modifier";
    }
}

function verifierNotif() {
    if (notif.hidden == false) {
        setTimeout(cacherAlert, 5000);
    }
}

function cacherAlert() {
    notif.hidden = true;
}

function verifMdp() {
    if (mdpAncien.value.length == 0 || mdp1.value.length < 8 || mdp2.value.length < 8 || mdp1.value != mdp2.value) {
        btnChanger.disabled = true;
    }
    else {
        btnChanger.disabled = false;
    }
}
