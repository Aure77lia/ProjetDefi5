<?php
    include('traitement/verifConnecte.php');

    $menuSuperAdmin = '';
    $iconeDroit = '';
    $numUnique = new DateTime();
    $numUnique = $numUnique->getTimestamp();
    
    if ($droit == 'super admin') {
        $menuSuperAdmin = '<a href="gestionComptes.php" class="list-group-item list-group-item-action list-group-item-light"><i class="fa-solid fa-list-ul fa-xl"></i>&nbsp;Gestion des comptes</a>';
        $iconeDroit = '&nbsp;<i class="fa-solid fa-crown" style="color: #FACD03"></i>';
    }
    elseif ($droit =='admin') {
        $iconeDroit = '&nbsp;<i class="fa-solid fa-user-tie" style="color: #F11212"></i>';
    }
    else {
        $iconeDroit = '&nbsp;<i class="fa-solid fa-user-lock" style="color: #76D108"></i>';
    }

    $notif =' hidden';
    $msgNotif = '';
    $entete = '';


    if (isset($_SESSION["notif"]) && $_SESSION["notif"] != '') {
        if ($_SESSION["notif"] == "modifier") {
            $entete = '<strong class="me-auto"><i class="bi-globe"></i><i class="fa-solid fa-circle-check" style="color: green"></i></i> Modifié</strong>';
            $msgNotif = 'Le mot de passe a bien été modifié.';
        }
        elseif ($_SESSION["notif"] == "tropCourt") {
            $entete = '<strong class="me-auto"><i class="bi-globe"></i><i class="fa-solid fa-circle-exclamation" style="color: red"></i> Erreur</strong>';
            $msgNotif = 'Le nouveau mot de passe est trop court. Celui-ci doit contenir au moins 8 caractères.';
        }
        elseif ($_SESSION["notif"] == "mdpAncienIncorrect") {
            $entete = '<strong class="me-auto"><i class="bi-globe"></i><i class="fa-solid fa-circle-exclamation" style="color: red"></i> Erreur</strong>';
            $msgNotif = 'Votre ancien mot de passe est incorrect.';
        }
        elseif ($_SESSION["notif"] == "nonIdentique") {
            $entete = '<strong class="me-auto"><i class="bi-globe"></i><i class="fa-solid fa-circle-exclamation" style="color: red"></i> Erreur</strong>';
            $msgNotif = 'Les mots de passe ne sont pas identiques.';
        }
        $notif ='';
        $_SESSION["notif"] = '';
    }

    echo'
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Mon compte</title>
        <link rel="icon" type="image/png" sizes="250x250" href="image\utilisateuriconeDroit.png?v=' . $numUnique . '">
    </head>
    <body>
        <div class="text-center">
            <h1>Mon compte</h1>
        </div>
        <br/><br/>
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-lg-2">
                    <div class="toast-container" style="position: absolute; top: 10px; left: 10px;">
                        <div class="toast fade show bg-white" id="notif"' . $notif . '>
                            <div class="toast-header">
                                ' . $entete .'
                            </div>
                            <div class="toast-body">
                                ' . $msgNotif . '
                            </div>
                        </div>
                    </div>
                    <div class="list-group">
                        <a href="index.php" class="list-group-item list-group-item-action list-group-item-light"><i class="fa-solid fa-table-list fa-xl"></i>&nbsp;Tableau de bord</a>
                        <a href="#" class="list-group-item list-group-item-action list-group-item-light active"><i class="fa-solid fa-user fa-xl"></i>&nbsp;Mes informations</a>
                        '. $menuSuperAdmin . '
                        <a href="traitement/traitementDeconnexion.php" class="list-group-item list-group-item-action list-group-item-light"><i class="fa-solid fa-arrow-right-from-bracket fa-xl"></i>&nbsp;Déconnexion</a>
                    </div>
                </div>
                <div class="d-block d-sm-none">
                    <br/>
                </div>
                <div class="col-12 col-lg-10">
                    <div class="card">
                        <div class="card-header">
                        </div>
                        <div class="card-body">
                            <h4 class="card-title">Mes informations</h4>
                            <p class="card-text">
                                <br/>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="row">
                                            <div class="col-4">
                                                <strong>Nom</strong>
                                            </div>
                                            <div class="col-8">
                                                ' . $nom . '
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-4">
                                                <strong>Prénom</strong>
                                            </div>
                                            <div class="col-8">
                                                ' . $prenom . '
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="row">
                                            <div class="col-4">
                                                <strong>Courriel</strong>
                                            </div>
                                            <div class="col-8">
                                                ' . $mail . '
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-4">
                                                <strong>Mot de passe</strong>
                                            </div>
                                            <div class="col-8">
                                                *********
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-6">
                                                <a href="#" id="btnModifier">Modifier</a>
                                                <form action="traitement/traitementModifierMdp.php" method="POST" class="text-start" id="modifierMdp" hidden>
                                                    <input type="password" class="form-control" value="" name="mdpAncien" id="mdpAncien" placeholder="Ancien mot de passe" required/><br/>
                                                    <input type="password" class="form-control" value="" name="mdp1" id="mdp1" placeholder="Nouveau mot de passe" required/>
                                                    <input type="password" class="form-control" value="" name="mdp2" id="mdp2" placeholder="Répéter le mot de passe" required/><br/>
                                                    <input class="btn btn-secondary" type="submit" id="btnChanger" value="Changer" disabled/>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="row">
                                            <div class="col-4">
                                                <strong>Droit</strong>
                                            </div>
                                            <div class="col-8">
                                                ' . strtoupper(substr($droit, 0, 1)) . substr($droit, 1, strlen($droit)) . $iconeDroit  . '
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </p>
                        </div>
                        <div class="card-footer text-muted">
                        </div>
                    </div>
                    <br/>';

                    echo '
                </div>
            </div>
        </div>
        <script src="js/scriptMonCompte.js?v=' . $numUnique . '"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
        </body>
    </html>';