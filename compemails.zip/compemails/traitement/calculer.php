<?php
    require('/home/communication/comm.dioceseparis.fr/www/compemails/fonctionInterface.php');
    traitement(listeFichier('LI', 4), listeFichier('Adel', 4));
?>