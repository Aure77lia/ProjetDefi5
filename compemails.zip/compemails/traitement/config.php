<?php 
    function connexionBDD() {
        $pdo = '';
        try {
            $pdo = new PDO('mysql:host=localhost;dbname=communication;port=3306;charset=UTF8', 'root' , 'root');
        }
        catch (PDOException $exception) {
            exit('Erreur de connexion à la base de données');
        }
        return $pdo;
    }

    function requeteRecupererHistorique() {
        $pdo = connexionBDD();
        $query = $pdo->query("SELECT numHistorique, idAdel, DATE_FORMAT(dateEnvoi, '%d/%m/%Y à %kh%i') as dateEnvoi, objet, message, adresseMail FROM compemails_historique;");
        $retour = $query->fetchAll(PDO::FETCH_ASSOC);
        return $retour;
    }

    function requeteRecupererException() {
        $pdo = connexionBDD();
        $requete = $pdo->prepare('SELECT * FROM compemails_exception;');
        $requete->execute(); 
        $retour = $requete->fetchAll(PDO::FETCH_ASSOC);
        return $retour;
    }

    function requeteRecupererCompte() {
        $pdo = connexionBDD();
        $query = $pdo->query("SELECT * FROM compemails_compte;");
        $retour = $query->fetchAll(PDO::FETCH_ASSOC);
        return $retour;
    }
    
    function requeteAjouterHistorique($idAdel, $objet, $message, $adresseMail) {
        $dateActuelle = date('Y-m-d H:i:s');
        $pdo = connexionBDD();
        $query = $pdo->prepare('    INSERT INTO compemails_historique (idAdel, dateEnvoi, objet, message, adresseMail)
                                    VALUES (:idAdel, :dateA, :objet, :messageMail, :adresseMail);');

        $query->bindValue(':idAdel', $idAdel, PDO::PARAM_STR);
        $query->bindValue(':dateA', $dateActuelle, PDO::PARAM_STR);
        $query->bindValue(':objet', $objet, PDO::PARAM_STR);
        $query->bindValue(':messageMail', $message, PDO::PARAM_STR);
        $query->bindValue(':adresseMail', $adresseMail, PDO::PARAM_STR);

        $c = $query->execute(); 
    }

    function requeteMaJParametre($cheminAdel) {
        $pdo = connexionBDD();
        $query = $pdo->query("  UPDATE compemails_parametre
                                SET valeur = '$cheminAdel'
                                WHERE idParametre = 2; ");
    }

    /*function requeteRecupererParametre() {
        $pdo = connexionBDD();
        $query = $pdo->query("SELECT * FROM compemails_parametre;");
        $retour = $query->fetchAll(PDO::FETCH_ASSOC);
        return $retour;
    }*/

    function requeteRecupererCompteEmail($mail) {        
        $pdo = connexionBDD();
        $requete = $pdo->prepare('SELECT * FROM compemails_compte WHERE mail = :mail');

        $requete->bindParam(':mail', $mail);

        $requete->execute(); 
        $retour = $requete->fetchAll(PDO::FETCH_ASSOC);
        return $retour;
    }

    function requeteModifierMdp($mdp, $mail) {        
        $pdo = connexionBDD();
        $requete = $pdo->prepare('  UPDATE compemails_compte
                                    SET mdp = :mdp
                                    WHERE mail = :mail');

        $requete->bindParam(':mdp', $mdp);
        $requete->bindParam(':mail', $mail);

        $requete->execute();
    }

    function requeteAjouterCompte($prenom, $nom, $mail, $mdp, $droit, $desactive) {        
        $pdo = connexionBDD();
        $query = $pdo->prepare('    INSERT INTO compemails_compte (prenom, nom, mail, mdp, droit, desactive)
                                    VALUES (:prenom, :nom, :mail, :mdp, :droit, :desactive);');

        $query->bindValue(':prenom', $prenom, PDO::PARAM_STR);
        $query->bindValue(':nom', $nom, PDO::PARAM_STR);
        $query->bindValue(':mail', $mail, PDO::PARAM_STR);
        $query->bindValue(':mdp', $mdp, PDO::PARAM_STR);
        $query->bindValue(':droit', $droit, PDO::PARAM_STR);
        $query->bindValue(':desactive', $desactive, PDO::PARAM_STR);

        $exe = $query->execute(); 
    }

    function requeteMaJCompte($numCompte, $prenom, $nom, $mail, $droit, $desactive) {
        $pdo = connexionBDD();
        $query = $pdo->query("  UPDATE compemails_compte
                                SET prenom = '$prenom'
                                WHERE numCompte = $numCompte; ");

        $query = $pdo->query("  UPDATE compemails_compte
                                SET nom = '$nom'
                                WHERE numCompte = $numCompte; ");

        $query = $pdo->query("  UPDATE compemails_compte
                                SET mail = '$mail'
                                WHERE numCompte = $numCompte; ");

        $query = $pdo->query("  UPDATE compemails_compte
                                SET droit = '$droit'
                                WHERE numCompte = $numCompte; ");

        $query = $pdo->query("  UPDATE compemails_compte
                                SET desactive = '$desactive'
                                WHERE numCompte = $numCompte; ");
    }

    function requeteSuppCompte($numCompte) {
        $pdo = connexionBDD();
        $query = $pdo->prepare('DELETE FROM compemails_compte
                                WHERE numCompte = :numCompte');

        $query->bindValue(':numCompte', $numCompte, PDO::PARAM_STR);

        $query->execute();
    }

    function requeteAjouterException($idLI) {
        $pdo = connexionBDD();
        $query = $pdo->prepare('INSERT INTO compemails_exception (idLI)
                                VALUES (:idLI);');

        $query->bindValue(':idLI', $idLI, PDO::PARAM_STR);

        $query->execute();
    }
    
    function requeteSuppException($idLI) {
        $pdo = connexionBDD();
        $query = $pdo->prepare('DELETE FROM compemails_exception
                                WHERE idLI = :idLI');

        $query->bindValue(':idLI', $idLI, PDO::PARAM_STR);

        $query->execute();
    }
    
    function requeteRecupererMailPre() {
        $pdo = connexionBDD();
        $query = $pdo->prepare('SELECT * FROM compemails_mailpre;');
        $query->execute(); 
        $retour = $query->fetchAll(PDO::FETCH_ASSOC);
        return $retour;
    }

    function requeteMaJMailPre($numMailPre, $campagne, $objet, $message) {
        $pdo = connexionBDD();
        $query = $pdo->query("  UPDATE compemails_mailpre
                                SET campagne = '$campagne'
                                WHERE numMailPre = $numMailPre; ");

        $query = $pdo->query("  UPDATE compemails_mailpre
                                SET objet = '$objet'
                                WHERE numMailPre = $numMailPre; ");

        $query = $pdo->query("  UPDATE compemails_mailpre
                                SET message = '$message'
                                WHERE numMailPre = $numMailPre; ");
    }
?>