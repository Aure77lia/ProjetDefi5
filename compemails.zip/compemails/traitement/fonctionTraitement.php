<?php

    function suppFichierCache($dir) {
        $it = new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS);
        $files = new RecursiveIteratorIterator($it,
                    RecursiveIteratorIterator::CHILD_FIRST);
        foreach($files as $file) {
            if ($file == '../cache/.htaccess'){
            }
            elseif ($file->isDir()) {
                rmdir($file->getRealPath());
            }
            else {
                unlink($file->getRealPath());
            }
        }
    }

    function genererMdp($taille) {
        $mdp = '';
        $alphabet = array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z');
        for ($i = 0 ; $i < $taille ; $i++) {
            $choix = rand(0, 2);
            if ($choix == 0 || $choix == 1) {
                $maj = rand(0, 1);
                $lettre = rand(0, sizeof($alphabet) - 1);
                if ($maj == 0) {
                    $mdp .= strtolower($alphabet[$lettre]);
                }
                else {
                    $mdp .= strtoUpper($alphabet[$lettre]);
                }
            }
            else {
                $mdp .= rand(0, 9);
            }
        }
        return $mdp;
    }

?>