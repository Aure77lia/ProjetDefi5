<?php
    include('verifConnecte.php');


    $type = $_GET['typeExport'];
    $tete = array();
    $nomFichier = '';
    $contenu = '';


    if ($type == 'tabProfilCorrect') {
        $tete = array("Prenom", "Nom", "Mail_Adel", "Mail_LI");
        $nomFichier = 'Profil_Correct.csv';
        $contenu = json_decode(file_get_contents('../cache/tabProfilCorrect.json'), true);
    }
    elseif ($type == 'tabMailDiff') {
        $tete = array("Prenom", "Nom", "Mail_Adel", "Mail_LI");
        $nomFichier = 'Mails_différents.csv';
        $contenu = json_decode(file_get_contents('../cache/tabMailDiff.json'), true);
    }
    elseif ($type == 'tabAdelManquant') {
        $tete = array("Prenom", "Nom", "Mail_LI");
        $nomFichier = 'Adel_Manquant.csv';
        $contenu = json_decode(file_get_contents('../cache/tabAdelManquant.json'), true);
    }
    elseif ($type == 'tabLIManquant') {
        $tete = array("Prenom", "Nom", "Mail_Adel");
        $nomFichier = 'LI_Manquant.csv';
        $contenu = json_decode(file_get_contents('../cache/tabLIManquant.json'), true);
    }
    elseif ($type == 'tabLIManquantAdelManquant') {
        $tete = array("Prenom", "Nom");
        $nomFichier = 'LI_Manquant_et_Adel_Manquant.csv';
        $contenu = json_decode(file_get_contents('../cache/tabLIManquantAdelManquant.json'), true);
    }
    elseif ($type == 'tabProfilOrphelin') {
        $tete = array("Prenom", "Nom", "Mail_LI");
        $nomFichier = 'Profil_orphelins.csv';
        $contenu = json_decode(file_get_contents('../cache/tabProfilOrphelin.json'), true);
    }
    else {
        header('Location: /compemails/index.php');
    }
    header("Content-type: text/csv");
    header("Content-Disposition: attachment; filename=$nomFichier");
    $output = fopen("php://output", "w");
    fputcsv($output, $tete);
    foreach($contenu as $ligne) {
        fputcsv($output, $ligne);
    }
    fclose($output);

?>