<?php
    require('verifConnecte.php');
    require('fonctionTraitement.php');

    if (isset($_GET['valeurLI']) && isset($_GET['valeurAdel'])) {
        $_SESSION['valeurLI'] = null;
        $_SESSION['valeurAdel'] = null;
        if ($_SESSION['droit'] == 'admin' || $_SESSION['droit'] == 'super admin') {
            $dir = '../cache';
            suppFichierCache($dir);
            $_SESSION['valeurLI'] = $_GET['valeurLI'];
            $_SESSION['valeurAdel'] = $_GET['valeurAdel'];
        }
        else {
            $_SESSION['notif'] = "refuse";
        }
    }
    header('Location: /compemails/index.php');

?>