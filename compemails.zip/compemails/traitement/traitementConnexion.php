<?php
    require('config.php');
    require('fonctionTraitement.php');

    session_start();
    if (isset($_POST['mail']) && isset($_POST['mdp'])) {
        $retour = requeteRecupererCompteEmail($_POST['mail']);
        if (sizeof($retour) == 0) {
            $_SESSION["incorrect"] = true;
            header('location: /compemails/connexion.php');
        }
        else {
            if ($retour[0]['desactive'] == 'non') {
                if (password_verify($_POST['mdp'], $retour[0]['mdp'])) {
                    $_SESSION['mail'] = $retour[0]['mail'];
                    $_SESSION['droit'] = $retour[0]['droit'];
                    $_SESSION['nom'] = $retour[0]['nom'];
                    $_SESSION['prenom'] = $retour[0]['prenom'];
                    $_SESSION['desactive'] = $retour[0]['desactive'];
                    header('Location: /compemails/index.php');
                }
                else {
                    $_SESSION["incorrect"] = true;
                    header('location: /compemails/connexion.php');
                }
            }
            else {
                $_SESSION["compteDesactive"] = true;
                header('location: /compemails/connexion.php');
            }
        }
    }
    else { 
        $_SESSION["remplirInfo"] = true;
        header('location: /compemails/connexion.php');
    }

?>