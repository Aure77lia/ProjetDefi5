<?php
    require('verifConnecte.php');
    require('config.php');
    require('fonctionTraitement.php');
    
    if ($droit == 'super admin') {
        if (isset($_POST['nom']) && isset($_POST['prenom']) && isset($_POST['mail']) && isset($_POST['droit']) && isset($_POST['mdp']) && isset($_POST['desactive'])) {
            if (empty($_POST['nom']) == false && empty($_POST['prenom']) == false && empty($_POST['mail']) == false && empty($_POST['mdp']) == false) {
                if (strlen($_POST['mdp']) > 7) {
                    $retour = requeteRecupererCompteEmail($_POST['mail']);
                    if (sizeof($retour) == 0) {
                        $prenomAjouter = mb_strtoupper(substr($_POST['prenom'], 0, 1)) . mb_strtolower(substr($_POST['prenom'], 1, strlen($_POST['prenom'])));
                        $nomAjouter = mb_strtoupper($_POST['nom']);
                        $mailAjouter = strtolower($_POST['mail']);
                        $mdph = password_hash($_POST['mdp'], PASSWORD_DEFAULT);
                        requeteAjouterCompte($prenomAjouter, $nomAjouter, $mailAjouter, $mdph, $_POST['droit'], $_POST['desactive']);
                        $_SESSION["notif"] = "cree";
                        header('Location: /compemails/gestionComptes.php');
                    }
                    else {
                        $_SESSION["notif"] = "mailDejaPris";
                        header('Location: /compemails/gestionComptes.php');
                    }
                }
                else {
                    $_SESSION["notif"] = "mdpTropCourt";
                    header('Location: /compemails/gestionComptes.php');
                }
            }
            else {
                $_SESSION["notif"] = "remplirInfo";
                header('Location: /compemails/gestionComptes.php');
            }
        }
        else {
            header('Location: /compemails/index.php');
        }
    }
    else {
        header('Location: /compemails/index.php');
    }

?>