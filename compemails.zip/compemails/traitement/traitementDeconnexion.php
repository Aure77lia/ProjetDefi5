<?php
    require('verifConnecte.php');


    session_destroy();
    header('Location: /compemails/connexion.php');

?>