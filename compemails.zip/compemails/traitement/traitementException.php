<?php
    require('verifConnecte.php');
    require('config.php');
    require('fonctionTraitement.php');
    
    if (isset($_GET['action']) && isset($_GET['idLI'])) {
        if ($_GET['action'] == 'ajout') {
            requeteAjouterException($_GET['idLI']);
        }
        elseif ($_GET['action'] == 'supp') {
            requeteSuppException($_GET['idLI']);
        }
    }

    header('Location: /compemails/index.php#titreOrphelin');
?>