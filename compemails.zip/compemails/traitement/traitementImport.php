<?php
    require('verifConnecte.php');
    
    if (isset($_SESSION['droit'])) {
        if ($_SESSION['droit'] == 'admin' || $_SESSION['droit'] == 'super admin') {
            $date = new DateTime();
            $date = $date->getTimestamp();
            $dossier = "/home/communication/comm.dioceseparis.fr/www/compemails/cacheBDD/";
            $nomFichier = 'Adel_' . $date . '.csv';
            $chemin = $dossier . $nomFichier;
            $dateVieuxFichier = '';
            $dateRecentFichier = '';

            if ($_FILES['fichier']['error'] > 0) {
                $_SESSION['notif'] = "erreurTransfert";
                header('Location: /compemails/index.php');
            }

            if (substr($_FILES['fichier']['name'], strlen($_FILES['fichier']['name']) - 4) != '.csv') {
                $_SESSION['notif'] = "formatIncorrect";
                header('Location: /compemails/index.php');
            }

            if (file_exists('/home/communication/comm.dioceseparis.fr/www/compemails/cacheBDD') == false) {
                mkdir('/home/communication/comm.dioceseparis.fr/www/compemails/cacheBDD');
            }

            $tableDateFichier = array();
            if (is_dir($dossier)) {
                if ($dh = opendir($dossier)) {
                    while (($fichier = readdir($dh)) !== false){
                        if ($fichier != '.' && $fichier != '..' && strpos($fichier, '.csv') && $fichier != $nomFichier) {
                            $datefichier = str_replace(".csv", "", $fichier);
                            $datefichier = str_replace("Adel_", "", $datefichier);
                            array_push($tableDateFichier, $datefichier);
                        }
                    }
                    closedir($dh);
                }
            }
            $dateVieuxFichier = min($tableDateFichier);
            $dateRecentFichier = max($tableDateFichier);
            if (sizeof($tableDateFichier) >= 4) {
                unlink($dossier . "Adel_" . $dateVieuxFichier . ".csv");
            }
            move_uploaded_file($_FILES['fichier']['tmp_name'], $chemin);
            $_SESSION['notif'] = "importe";
        }
        else {
            $_SESSION['notif'] = "refuse";
        }
    }
    header('Location: /compemails/index.php');
?>