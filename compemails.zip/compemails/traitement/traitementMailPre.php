<?php
    require('verifConnecte.php');
    require('config.php');
    require('fonctionTraitement.php');
    
    if ($_SESSION['droit'] == 'admin' || $_SESSION['droit'] == 'super admin') {
        if (isset($_POST['numMailPreDiff']) && isset($_POST['campagneDiff']) && isset($_POST['objetDiff']) && isset($_POST['contenuMailDiff']) && isset($_POST['numMailPreAdel']) && isset($_POST['campagneAdel']) && isset($_POST['objetAdel']) && isset($_POST['contenuMailAdel'])) {
                requeteMaJMailPre($_POST['numMailPreDiff'], $_POST['campagneDiff'], $_POST['objetDiff'], $_POST['contenuMailDiff']);
                requeteMaJMailPre($_POST['numMailPreAdel'], $_POST['campagneAdel'], $_POST['objetAdel'], $_POST['contenuMailAdel']);
                $_SESSION['notif'] = "modifie";
        }
    }
    else {
        $_SESSION['notif'] = "refuse";
    }

    header('Location: /compemails/index.php');
?>