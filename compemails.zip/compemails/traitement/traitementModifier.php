<?php
    require('verifConnecte.php');
    require('config.php');
    require('fonctionTraitement.php');

    if ($droit == "super admin") {
        if (isset($_POST['numCompte'])) {
            if (empty($_POST['prenom']) == false && empty($_POST['nom']) == false && empty($_POST['mail']) == false && empty($_POST['droit']) == false && empty($_POST['desactive']) == false) {
                $retour = requeteRecupererCompteEmail($_POST['mail']);
                if ($retour[0]['numCompte'] == $_POST['numCompte'] || sizeof($retour) == 0) {
                    $prenomAjouter = mb_strtoupper(substr($_POST['prenom'], 0, 1)) . mb_strtolower(substr($_POST['prenom'], 1, strlen($_POST['prenom'])));
                    $nomAjouter = mb_strtoupper($_POST['nom']);
                    $mailAjouter = strtolower($_POST['mail']);
                    requeteMaJCompte($_POST['numCompte'], $prenomAjouter, $nomAjouter, $mailAjouter, $_POST['droit'], $_POST['desactive']);
                    $_SESSION["notif"] = "modifie";
                    header('Location: /compemails/gestionComptes.php');
                }
                else {
                    $_SESSION["notif"] = "mailDejaPris";
                    header('Location: /compemails/gestionComptes.php');
                }
            }
            else {
                $_SESSION["notif"] = "remplirInfo";
                header('Location: /compemails/gestionComptes.php');
            }
        }
        else {
            header('Location: /compemails/gestionComptes.php');
        }
    }
    else {
        header('Location: /compemails/monCompte.php');
    }


?>