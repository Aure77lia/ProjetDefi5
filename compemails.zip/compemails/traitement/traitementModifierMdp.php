<?php
    require('verifConnecte.php');
    require('config.php');
    require('fonctionTraitement.php');

    if (isset($_POST['mdpAncien']) && isset($_POST['mdp1']) && isset($_POST['mdp2'])) {    
        $retour = requeteRecupererCompteEmail($mail);
        if (password_verify($_POST['mdpAncien'], $retour[0]['mdp'])) {
            if ($_POST['mdp1'] == $_POST['mdp2']) {
                if (strlen($_POST['mdp1']) > 7) {
                    $mdph = password_hash($_POST['mdp1'], PASSWORD_DEFAULT);
                    requeteModifierMdp($mdph, $mail);
                    $_SESSION["notif"] = "modifier";
                    header('Location: /compemails/monCompte.php');
                }
                else {
                    $_SESSION["notif"] = "tropCourt";
                    header('location: /compemails/monCompte.php');
                }
            }
            else {
                $_SESSION["notif"] = "nonIdentique";
                header('location: /compemails/monCompte.php');
            }
        }
        else {
            $_SESSION["notif"] = "mdpAncienIncorrect";
            header('location: /compemails/monCompte.php');
        }
    }
    else {
        header('Location: /compemails/index.php');
    }

?>