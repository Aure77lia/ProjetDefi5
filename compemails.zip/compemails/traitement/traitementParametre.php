<?php
    require('verifConnecte.php');
    
    $_SESSION['erreurImportante'] = false;
    if (isset($_GET['erreurImportante'])) {
        $_SESSION['erreurImportante'] = true;
    }

    header('Location: /compemails/index.php');
?>