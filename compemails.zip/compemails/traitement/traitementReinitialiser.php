<?php
    require('verifConnecte.php');
    require('config.php');
    require('fonctionTraitement.php');

    if ($droit == "super admin") {
        if (isset($_POST['mail'])) {
            $mdp = genererMdp(8);
            $mdph = password_hash($mdp, PASSWORD_DEFAULT);
            requeteModifierMdp($mdph, $_POST['mail']);
            $_SESSION['reinitialise'] = $mdp;
            header('Location: /compemails/gestionComptes.php');
        }
        else {
            header('Location: /compemails/gestionComptes.php');
        }
    }
    else {
        header('Location: /compemails/monCompte.php');
    }
?>