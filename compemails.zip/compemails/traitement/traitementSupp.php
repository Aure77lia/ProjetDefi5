<?php
    require('verifConnecte.php');
    require('config.php');
    require('fonctionTraitement.php');

    if ($droit == "super admin") {
        if (isset($_POST['numCompte'])) {
            requeteSuppCompte($_POST['numCompte']);
            $_SESSION['notif'] = "supprime";
            header('Location: /compemails/gestionComptes.php');
        }
        else {
            header('Location: /compemails/gestionComptes.php');
        }
    }
    else {
        header('Location: /compemails/monCompte.php');
    }
?>