<?php

    session_start();
    if (isset($_SESSION['mail']) && isset($_SESSION['droit']) && isset($_SESSION['prenom']) && isset($_SESSION['nom'])) {
        $mail = $_SESSION['mail'];
        $droit = $_SESSION['droit'];
        $nom = $_SESSION['nom'];
        $prenom = $_SESSION['prenom'];
        $desactive = $_SESSION['desactive'];
    }
    else {
        header('Location: /compemails/connexion.php');
        die();
    }

?>